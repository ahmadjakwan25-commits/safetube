package com.safetube.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B1514)
val Card = Color(0xFF12201E)
val Accent = Color(0xFF2BB5A0)
val Muted = Color(0xFF9DB5B0)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.Black,
    background = Bg,
    surface = Card,
    surfaceVariant = Color(0xFF1B2D2A),
    onBackground = Color(0xFFE6F2F0),
    onSurface = Color(0xFFE6F2F0),
    onSurfaceVariant = Muted
)

@Composable
fun SafeTubeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
