package com.safetube.app

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer

/** তাড়াতাড়ি চালু হওয়ার জন্য: মাত্র ১ সেকেন্ডের ডেটা জমলেই চালানো শুরু করে */
fun newFastPlayer(ctx: Context): ExoPlayer {
    val lc = DefaultLoadControl.Builder()
        .setBufferDurations(15_000, 50_000, 1_000, 2_000)
        .build()
    return ExoPlayer.Builder(ctx).setLoadControl(lc).build()
}

/** মিউজিক ট্যাবের অডিও প্লেয়ার। অ্যাপের সাথে একটাই থাকে, ট্যাব বদলালেও থামে না। */
object Audio {
    lateinit var player: ExoPlayer

    fun init(ctx: Context) {
        player = ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurations(15_000, 50_000, 1_000, 2_000).build())
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    fun pause() {
        try { player.pause() } catch (e: Exception) { }
    }
}
