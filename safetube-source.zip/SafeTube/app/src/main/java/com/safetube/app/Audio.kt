package com.safetube.app

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer

/** তাড়াতাড়ি চালু হওয়ার জন্য: মাত্র ১ সেকেন্ডের ডেটা জমলেই চালানো শুরু করে */
fun newFastPlayer(ctx: Context): ExoPlayer {
    val lc = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15_000, 50_000, 1_000, 2_000)
        .build()
    return ExoPlayer.Builder(ctx).setLoadControl(lc).build()
}

/** মিউজিক ট্যাবের অডিও প্লেয়ার। অ্যাপের সাথে একটাই থাকে, ট্যাব বদলালেও থামে না। */
object Audio {
    lateinit var player: ExoPlayer

    fun init(ctx: Context) {
        player = ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_000, 2_000).build())
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    fun pause() {
        try { player.pause() } catch (e: Exception) { }
    }
}

/** সাধারণ ভিডিওর প্লেয়ার। পর্দা বন্ধ বা অ্যাপ ঘুরলেও টিকে থাকে, তাই ভিডিও শুরু থেকে আসে না। */
object Video {
    lateinit var player: ExoPlayer
    var currentUrl: String? = null
    var runner: SourceRunner? = null

    // "পরের ভিডিও" চাপলে নতুন পর্দা খোলে; পুরো পর্দা অবস্থা যাতে না হারায়
    var fullscreenCarry = false

    fun init(ctx: Context) {
        player = ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 50_000, 1_000, 2_000).build())
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            // ডান/বাঁ পাশে চাপ আর কন্ট্রোলের ⏪ ⏩ বোতাম, দুটোতেই ১০ সেকেন্ড
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    fun stop() {
        runner?.stop()
        runner = null
        currentUrl = null
        try {
            player.repeatMode = Player.REPEAT_MODE_OFF
            player.stop()
            player.clearMediaItems()
        } catch (e: Exception) { }
    }
}
