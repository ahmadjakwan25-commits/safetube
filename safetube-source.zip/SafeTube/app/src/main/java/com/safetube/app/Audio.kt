package com.safetube.app

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer

/** মিউজিক ট্যাবের অডিও প্লেয়ার। অ্যাপের সাথে একটাই থাকে, ট্যাব বদলালেও থামে না। */
object Audio {
    lateinit var player: ExoPlayer

    fun init(ctx: Context) {
        player = ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
    }

    fun pause() {
        try { player.pause() } catch (e: Exception) { }
    }
}
