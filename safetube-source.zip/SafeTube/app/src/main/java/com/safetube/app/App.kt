package com.safetube.app

import android.app.Application
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Audio.init(this)
        NewPipe.init(DownloaderImpl, Localization("bn", "BD"), ContentCountry("BD"))
    }
}
