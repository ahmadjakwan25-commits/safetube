package com.safetube.app

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize

/** ভিডিওর কোন অংশে চাপা হলো: -1 = বাঁ পাশ, +1 = ডান পাশ, 0 = অন্য কোথাও (মাঝের প্লে বোতাম, ওপরের বোতাম, নিচের সিকবার) */
private fun seekZone(p: Offset, size: IntSize): Int {
    val w = size.width.toFloat()
    val h = size.height.toFloat()
    if (w <= 0f || h <= 0f) return 0
    if (p.y < h * 0.15f || p.y > h * 0.78f) return 0
    return when {
        p.x < w * 0.40f -> -1
        p.x > w * 0.60f -> 1
        else -> 0
    }
}

/**
 * ইউটিউবের মতো: ডান পাশে দুইবার চাপলে [onSeek](+1), বাম পাশে দুইবার চাপলে [onSeek](-1)।
 * দুইবার চাপার পর ০.৬৫ সেকেন্ডের মধ্যে আরও চাপলে প্রতি চাপে আবার একবার করে কাজ করে।
 * প্রথম চাপটা আগের মতোই প্লেয়ারের কন্ট্রোল দেখায়/লুকায়; দ্বিতীয় থেকে পরের চাপগুলো প্লেয়ারকে পৌঁছায় না।
 *
 * [enabled] আর [onSeek] শুধু State পড়ে এমন ল্যাম্বডা হতে হবে, কারণ জেসচারের ব্লক একবারই তৈরি হয়।
 */
fun Modifier.doubleTapSeek(enabled: () -> Boolean, onSeek: (Int) -> Unit): Modifier =
    pointerInput(Unit) {
        var lastUp = 0L
        var lastZone = 0
        var chain = false
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val zone = if (enabled()) seekZone(down.position, size) else 0
            val limit = if (chain) 650L else 300L
            val continues = zone != 0 && zone == lastZone && (down.uptimeMillis - lastUp) in 0L..limit
            if (continues) down.consume()

            var tap = true
            var up: PointerInputChange? = null
            var event = awaitPointerEvent(PointerEventPass.Initial)
            while (true) {
                if (event.changes.size > 1) tap = false
                val c = event.changes.firstOrNull { it.id == down.id }
                if (c == null) {
                    tap = false
                } else {
                    if ((c.position - down.position).getDistance() > viewConfiguration.touchSlop) tap = false
                    if (c.uptimeMillis - down.uptimeMillis > 400L) tap = false
                    if (continues) c.consume()
                    if (!c.pressed && up == null) up = c
                }
                if (event.changes.none { it.pressed }) break
                event = awaitPointerEvent(PointerEventPass.Initial)
            }

            val upChange = up
            if (tap && zone != 0 && upChange != null) {
                if (continues) {
                    chain = true
                    onSeek(zone)
                } else {
                    chain = false
                }
                lastUp = upChange.uptimeMillis
                lastZone = zone
            } else {
                chain = false
                lastZone = 0
            }
        }
    }
