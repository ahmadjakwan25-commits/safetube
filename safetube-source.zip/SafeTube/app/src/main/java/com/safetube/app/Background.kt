package com.safetube.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * ভিডিও বা অডিও চলার সময় অ্যাপকে "চালু" রাখে, যাতে স্ক্রিন বন্ধ করলে বা অন্য অ্যাপে গেলে ফোন সেটা বন্ধ না করে দেয়।
 */
class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title") ?: "মুসলিম টিউব"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("playback", "চলছে", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "playback")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("মুসলিম টিউব")
            .setContentText(title)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }
}

object Keep {
    private var video = false
    private var audio = false

    fun videoStart(ctx: Context, title: String) {
        video = true
        start(ctx, title)
    }

    fun videoStop(ctx: Context) {
        video = false
        maybeStop(ctx)
    }

    fun audioStart(ctx: Context, title: String) {
        audio = true
        start(ctx, title)
    }

    fun audioStop(ctx: Context) {
        audio = false
        maybeStop(ctx)
    }

    private fun start(ctx: Context, title: String) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java).putExtra("title", title))
        } catch (e: Exception) { }
    }

    private fun maybeStop(ctx: Context) {
        if (!video && !audio) {
            try { ctx.stopService(Intent(ctx, KeepAliveService::class.java)) } catch (e: Exception) { }
        }
    }
}
