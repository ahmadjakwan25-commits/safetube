package com.safetube.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** অ্যাপের ভেতরে ছোট ভাসমান ভিডিও: চাপলে আবার বড় হয়, ✕ চাপলে বন্ধ হয় */
@Composable
fun MiniVideo(vm: MainVm, t: YtTheme, modifier: Modifier) {
    val view = LocalView.current
    var playing by remember { mutableStateOf(Video.player.isPlaying) }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlayingNow: Boolean) {
                playing = isPlayingNow
            }
        }
        Video.player.addListener(l)
        onDispose { Video.player.removeListener(l) }
    }
    DisposableEffect(playing) {
        view.keepScreenOn = playing
        onDispose { view.keepScreenOn = false }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .width(200.dp)
            .aspectRatio(16f / 9f)
            .clip(shape)
            .background(Color.Black)
            .border(1.dp, t.line, shape)
            .clickable { vm.minimized = false }
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = Video.player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Row(Modifier.align(Alignment.BottomEnd).padding(4.dp)) {
            Text(
                if (playing) "⏸" else "▶", color = Color.White, fontSize = 16.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0x99000000))
                    .clickable { if (Video.player.isPlaying) Video.player.pause() else Video.player.play() }
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            )
            Text(
                "✕", color = Color.White, fontSize = 16.sp,
                modifier = Modifier
                    .padding(start = 6.dp)
                    .clip(CircleShape)
                    .background(Color(0x99000000))
                    .clickable { vm.closePlayer() }
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            )
        }
    }
}

/** সিস্টেমের ছোট জানালায় (PiP) শুধু ভিডিওটা দেখায় */
@Composable
fun PipVideo() {
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                player = Video.player
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        },
        modifier = Modifier.fillMaxSize().background(Color.Black)
    )
}
