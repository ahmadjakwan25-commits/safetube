package com.safetube.app

import org.schabi.newpipe.extractor.stream.StreamInfo

data class Verdict(val ok: Boolean, val reason: String)

/**
 * ভিডিও চালানোর আগে স্ক্রিনিং: শুধু সার্চের শব্দ নয়, ভিডিওর শিরোনাম, ট্যাগ, বিবরণ,
 * ক্যাটাগরি আর বয়সসীমা দেখে ঠিক করে চালানো যাবে কি না।
 */
object Screening {
    // এই ধরনের ক্যাটাগরির ভিডিও চালাতে হলে ইসলামিক প্রমাণ বেশি লাগে
    private val RISKY = listOf(
        "music", "film", "entertainment", "comedy", "shows", "movies", "trailers", "gaming", "sports"
    )

    fun check(info: StreamInfo, v: VideoItem, desc: String, strict: Boolean): Verdict {
        if (info.ageLimit > 0) return Verdict(false, "ভিডিওটিতে বয়সসীমা দেওয়া আছে")

        val tags = try { info.tags.joinToString(" ") } catch (e: Exception) { "" }
        val head = v.title + " " + (info.uploaderName ?: "") + " " + tags
        val body = desc.take(1500)

        if (ContentFilter.isBad(head)) return Verdict(false, "শিরোনাম, চ্যানেল বা ট্যাগে অনুচিত শব্দ আছে")
        if (ContentFilter.isStrongBad(body)) return Verdict(false, "বিবরণে অনুচিত শব্দ আছে")

        val cat = (info.category ?: "").lowercase()
        val score = ContentFilter.islamicScore(head + " " + body)
        val risky = RISKY.any { cat.contains(it) }

        if (risky && score < 2) {
            return Verdict(false, "এটা বিনোদন বা গানের ধরনের ভিডিও, ইসলামিক বিষয়ের পর্যাপ্ত প্রমাণ নেই")
        }
        if (strict && score < 1) {
            return Verdict(false, "ইসলামিক বিষয় বলে প্রমাণ পাওয়া যায়নি")
        }
        return Verdict(true, "")
    }
}
