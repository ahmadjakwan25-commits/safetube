package com.safetube.app

import android.content.res.Configuration
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(video: VideoItem, vm: MainVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalYt.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var status by remember { mutableStateOf("লোড হচ্ছে…") }
    var ready by remember { mutableStateOf(false) }
    var desc by remember { mutableStateOf("") }
    var dlUrl by remember { mutableStateOf<String?>(null) }
    var related by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var info by remember { mutableStateOf<StreamInfo?>(null) }
    var likeCount by remember { mutableStateOf(-1L) }
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsMsg by remember { mutableStateOf("মন্তব্য আসছে…") }
    var commentInfo by remember { mutableStateOf<CommentsInfo?>(null) }
    var commentNext by remember { mutableStateOf<Page?>(null) }
    var showAllComments by remember { mutableStateOf(false) }
    var moreLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val okComment = { c: CommentItem -> c.text.isNotBlank() && !ContentFilter.isStrongBad(c.text + " " + c.author) }

    val saved = vm.isSaved(video)
    val liked = vm.isLiked(video)
    val dl = vm.downloads.firstOrNull { it.video.url == video.url }
    val dlPct: Int? = dl?.let { vm.dlProgress[it.dlId] }

    DisposableEffect(Unit) { onDispose { player.release() } }

    // ডাউনলোডের অগ্রগতি দেখাতে
    LaunchedEffect(dl?.dlId) {
        while (dl != null) {
            vm.refreshDownloads()
            delay(1500)
        }
    }

    LaunchedEffect(video.url) {
        try {
            val local = vm.localFile(video)
            if (local != null) {
                player.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(local))))
                player.prepare()
                player.playWhenReady = true
                ready = true
                vm.addHistory(video)
                return@LaunchedEffect
            }
            val si = withContext(Dispatchers.IO) { Repo.streamInfo(video.url) }
            val d = try { si.description?.content ?: "" } catch (e: Exception) { "" }
            val verdict = Screening.check(si, video, d, vm.islamicOnly)
            if (!verdict.ok) {
                status = "🚫 এই ভিডিও চালানো যাবে না।\nকারণ: " + verdict.reason
                return@LaunchedEffect
            }
            info = si
            likeCount = si.likeCount
            desc = d
            dlUrl = Repo.muxedUrl(si)
            val src = withContext(Dispatchers.IO) { Repo.buildSource(si) }
            if (src == null) {
                status = "এই ভিডিওর চালানোর মতো লিংক পাওয়া যায়নি।"
                return@LaunchedEffect
            }
            player.setMediaSource(src)
            player.prepare()
            player.playWhenReady = true
            ready = true
            vm.addHistory(video)
            related = withContext(Dispatchers.IO) { Repo.related(si) }.filter { vm.keep(it) }
        } catch (e: Exception) {
            status = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    LaunchedEffect(info) {
        val i = info ?: return@LaunchedEffect
        try {
            val cp = withContext(Dispatchers.IO) { Repo.comments(i) }
            comments = cp.items.filter(okComment)
            commentInfo = cp.info
            commentNext = cp.next
            commentsMsg = if (comments.isEmpty()) "কোনো মন্তব্য পাওয়া যায়নি।" else ""
        } catch (e: Exception) {
            commentsMsg = "মন্তব্য বন্ধ আছে বা আনা যায়নি।"
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(t.bg)
    ) {
        if (!landscape) YtHeader(t, onBack = onBack)
        val box = if (landscape) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        Box(box.background(Color.Black), contentAlignment = Alignment.Center) {
            if (ready) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { this.player = player; useController = true } },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (status == "লোড হচ্ছে…") {
                CircularProgressIndicator(color = t.accent)
            } else {
                Text(status, color = Color.White, modifier = Modifier.padding(16.dp))
            }
        }
        if (!landscape) {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Text(video.title, color = t.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(video.channel, color = t.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        Row(Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionChip(if (likeCount >= 0) "👍 ${fmtCount(likeCount)}" else "👍 পছন্দ", liked, t) { vm.toggleLike(video) }
                            ActionChip(if (saved) "🔖 সংরক্ষিত" else "🔖 সংরক্ষণ", saved, t) { vm.toggleSave(video) }
                            val label = when {
                                dl == null -> "⬇ ডাউনলোড"
                                dlPct == null || dlPct in 0..99 -> "⏳ নামছে ${dlPct ?: 0}%"
                                dlPct == 100 -> "✅ ডাউনলোড হয়েছে"
                                else -> "⚠ ব্যর্থ, আবার করুন"
                            }
                            ActionChip(label, dlPct == 100, t) {
                                if (dl == null) {
                                    val u = dlUrl
                                    if (u == null) {
                                        Toast.makeText(ctx, "এই ভিডিওর ডাউনলোড লিংক পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                                    } else {
                                        vm.startDownload(video, u)
                                        Toast.makeText(ctx, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show()
                                    }
                                } else if (dlPct != null && dlPct < 0) {
                                    vm.deleteDownload(dl)
                                    val u = dlUrl
                                    if (u != null) vm.startDownload(video, u)
                                }
                            }
                        }
                        if (desc.isNotBlank()) {
                            Text(
                                desc.take(300), color = t.muted, fontSize = 12.5.sp,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }
                    }
                }
                item {
                    CommentsBox(
                        t, comments, commentsMsg, showAllComments, moreLoading, commentNext != null,
                        onToggle = { showAllComments = !showAllComments },
                        onMore = {
                            val ci = commentInfo
                            val pg = commentNext
                            if (ci != null && pg != null && !moreLoading) {
                                scope.launch {
                                    moreLoading = true
                                    try {
                                        val cp = withContext(Dispatchers.IO) { Repo.moreComments(ci, pg) }
                                        comments = comments + cp.items.filter(okComment)
                                        commentNext = cp.next
                                    } catch (e: Exception) {
                                        commentNext = null
                                    } finally {
                                        moreLoading = false
                                    }
                                }
                            }
                        }
                    )
                }
                if (related.isNotEmpty()) {
                    item {
                        Text("আরও দেখুন", color = t.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                items(related) { r -> VideoCard(r, t) { vm.current = r } }
            }
        }
    }
}

@Composable
private fun ActionChip(label: String, on: Boolean, t: YtTheme, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        label,
        color = if (on) t.onAccent else t.text,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(shape)
            .background(if (on) t.chipOn else t.panel)
            .border(1.dp, if (on) t.chipOn else t.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun CommentsBox(
    t: YtTheme,
    comments: List<CommentItem>,
    msg: String,
    showAll: Boolean,
    moreLoading: Boolean,
    hasMore: Boolean,
    onToggle: () -> Unit,
    onMore: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(t.panel)
            .border(1.dp, t.line, shape)
            .padding(12.dp)
    ) {
        Text("💬 মন্তব্য", color = t.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (msg.isNotEmpty()) {
            Text(msg, color = t.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        val shown = if (showAll) comments else comments.take(3)
        for (c in shown) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(t.accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(c.author.trimStart('@').take(1).ifEmpty { "?" }, color = t.onAccent, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        c.author + if (c.date.isNotEmpty()) "  ·  " + c.date else "",
                        color = t.muted, fontSize = 11.5.sp, maxLines = 1
                    )
                    Text(
                        c.text, color = t.text, fontSize = 13.5.sp,
                        maxLines = if (showAll) 12 else 4,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    if (c.likes > 0) {
                        Text("👍 ${c.likes}", color = t.muted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 3.dp))
                    }
                }
            }
        }
        if (comments.size > 3 || (comments.isNotEmpty() && hasMore)) {
            Row(Modifier.padding(top = 6.dp)) {
                if (comments.size > 3) {
                    TextButton(onClick = onToggle) {
                        Text(if (showAll) "কম দেখান" else "সব মন্তব্য দেখুন", color = t.chipOn)
                    }
                }
                if (showAll && hasMore) {
                    TextButton(onClick = onMore) {
                        Text(if (moreLoading) "আসছে…" else "আরও মন্তব্য", color = t.chipOn)
                    }
                }
            }
        }
    }
}
