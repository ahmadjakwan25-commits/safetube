package com.safetube.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(video: VideoItem, vm: MainVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val t = LocalYt.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val player = Video.player
    var attempt by remember { mutableIntStateOf(0) }
    var retryable by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("লোড হচ্ছে…") }
    var ready by remember { mutableStateOf(false) }
    var desc by remember { mutableStateOf("") }
    var dlUrl by remember { mutableStateOf<String?>(null) }
    var related by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var info by remember { mutableStateOf<StreamInfo?>(null) }
    var likeCount by remember { mutableStateOf(-1L) }
    var dislikeCount by remember { mutableStateOf(-1L) }
    var showDesc by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentsMsg by remember { mutableStateOf("মন্তব্য আসছে…") }
    var commentInfo by remember { mutableStateOf<CommentsInfo?>(null) }
    var commentNext by remember { mutableStateOf<Page?>(null) }
    var showAllComments by remember { mutableStateOf(false) }
    var moreLoading by remember { mutableStateOf(false) }
    var channelName by remember { mutableStateOf(video.channel) }
    var channelIcon by remember { mutableStateOf(video.channelIcon) }
    var channelUrlS by remember { mutableStateOf(video.channelUrl) }
    var subs by remember { mutableStateOf(-1L) }
    var viewCount by remember { mutableStateOf(video.views) }
    var fullscreen by remember { mutableStateOf(Video.fullscreenCarry).also { Video.fullscreenCarry = false } }
    var repeatOne by remember { mutableStateOf(player.repeatMode == Player.REPEAT_MODE_ONE) }
    var seekFlash by remember { mutableIntStateOf(0) }
    var seekKey by remember { mutableIntStateOf(0) }
    var menuOpen by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var qualityLabels by remember { mutableStateOf<List<String>>(emptyList()) }
    var qualityIdx by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    var isPlaying by remember { mutableStateOf(player.isPlaying) }
    val activity = remember(ctx) { ctx.findActivity() }
    val scope = rememberCoroutineScope()
    val okComment = { c: CommentItem -> c.text.isNotBlank() && !ContentFilter.isStrongBad(c.text + " " + c.author) }

    val saved = vm.isSaved(video)
    val liked = vm.isLiked(video)
    val dl = vm.videoDownload(video)
    val dlPct: Int? = dl?.let { vm.dlProgress[it.dlId] }

    // ভিডিও চলার সময় স্ক্রিন বন্ধ হবে না
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                repeatOne = repeatMode == Player.REPEAT_MODE_ONE
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }
    DisposableEffect(isPlaying) {
        view.keepScreenOn = isPlaying
        onDispose { view.keepScreenOn = false }
    }

    BackHandler(enabled = fullscreen) { fullscreen = false }

    // পুরো পর্দা: আড়াআড়ি করে আর সিস্টেম বার লুকিয়ে
    LaunchedEffect(fullscreen, landscape) {
        val a = activity ?: return@LaunchedEffect
        val ctrl = WindowCompat.getInsetsController(a.window, a.window.decorView)
        a.requestedOrientation = if (fullscreen) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (fullscreen || landscape) {
            ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctrl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            ctrl.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.let { a ->
                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(a.window, a.window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // ডাউনলোডের অগ্রগতি দেখাতে
    LaunchedEffect(dl?.dlId) {
        while (dl != null) {
            vm.refreshDownloads()
            delay(1500)
        }
    }

    LaunchedEffect(video.url, attempt) {
        Audio.pause()
        // অ্যাপ ঘুরে/পর্দা বন্ধ হয়ে ফিরলে একই ভিডিও থাকলে নতুন করে শুরু না করে যেখানে ছিল সেখান থেকেই চলে
        val resuming = attempt == 0 && Video.currentUrl == video.url && player.mediaItemCount > 0
        if (!resuming) {
            Video.runner?.stop()
            Video.runner = null
            player.repeatMode = Player.REPEAT_MODE_OFF
        }
        status = "লোড হচ্ছে…"
        retryable = false
        try {
            val local = vm.localFile(video)
            if (local != null) {
                if (!resuming) {
                    player.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(local))))
                    player.prepare()
                    player.playWhenReady = true
                    Video.currentUrl = video.url
                    vm.addHistory(video)
                }
                qualityLabels = emptyList()
                ready = true
                vm.videoStarted(video)
                return@LaunchedEffect
            }
            val si = withContext(Dispatchers.IO) { Repo.streamInfo(video.url) }
            val d = try { si.description?.content ?: "" } catch (e: Exception) { "" }
            val verdict = Screening.check(si, video, d, vm.screenStrict(video))
            if (!verdict.ok) {
                status = "🚫 এই ভিডিও চালানো যাবে না।\nকারণ: " + verdict.reason
                return@LaunchedEffect
            }
            info = si
            likeCount = si.likeCount
            channelName = si.uploaderName ?: video.channel
            channelIcon = si.uploaderAvatars.firstOrNull()?.url ?: video.channelIcon
            channelUrlS = (si.uploaderUrl ?: "").ifEmpty { video.channelUrl }
            subs = si.uploaderSubscriberCount
            if (si.viewCount > 0) viewCount = si.viewCount
            desc = d
            dlUrl = Repo.muxedUrl(si)
            val cands = Repo.candidates(si)
            qualityLabels = cands.map { it.label }
            if (cands.isEmpty()) {
                status = "এই ভিডিওর চালানোর মতো লিংক পাওয়া যায়নি।"
                retryable = true
                return@LaunchedEffect
            }
            val failCb = { msg: String ->
                ready = false
                status = "ভিডিও চালানো যায়নি ($msg)"
                retryable = true
            }
            val existing = Video.runner
            if (resuming && existing != null) {
                existing.onFail = failCb
                existing.onIndex = { i -> qualityIdx = i }
                qualityIdx = existing.index
            } else {
                val r = SourceRunner(player, cands, failCb) { i -> qualityIdx = i }
                Video.runner = r
                Video.currentUrl = video.url
                r.start()
                vm.addHistory(video)
            }
            ready = true
            vm.videoStarted(video)
            related = withContext(Dispatchers.IO) { Repo.related(si) }.filter { vm.keep(it) }
        } catch (e: Exception) {
            status = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            retryable = true
        }
    }

    LaunchedEffect(video.url) {
        dislikeCount = withContext(Dispatchers.IO) { Repo.dislikes(video.url) }
    }

    LaunchedEffect(info) {
        val i = info ?: return@LaunchedEffect
        try {
            val cp = withContext(Dispatchers.IO) { Repo.comments(i) }
            comments = cp.items.filter(okComment)
            commentInfo = cp.info
            commentNext = cp.next
            commentsMsg = if (comments.isEmpty()) "কোনো মন্তব্য পাওয়া যায়নি।" else ""
        } catch (e: Exception) {
            commentsMsg = "মন্তব্য বন্ধ আছে বা আনা যায়নি।"
        }
    }

    // ডান/বাঁ পাশে দুইবার (বা আরও) চাপলে ১০ সেকেন্ড করে সামনে/পিছনে
    LaunchedEffect(seekKey) {
        if (seekKey > 0) {
            delay(800)
            seekFlash = 0
        }
    }
    val doSeek: (Int) -> Unit = { dir ->
        val dur = player.duration
        var target = player.currentPosition + dir * 10_000L
        if (target < 0L) target = 0L
        if (dur != C.TIME_UNSET && dur > 0L && target > dur) target = dur
        player.seekTo(target)
        seekFlash = if (seekFlash != 0 && (seekFlash > 0) == (dir > 0)) seekFlash + dir * 10 else dir * 10
        seekKey++
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(t.bg)
    ) {
        val full = fullscreen || landscape
        if (!full) YtHeader(t, onBack = onBack)
        val box = if (full) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        // পুরো পর্দায় দুই আঙুলে চিমটি কেটে ভিডিও ছোট-বড় করা যায়; পর্দা ছোট হলে আবার স্বাভাবিক হয়
        LaunchedEffect(full) {
            if (!full) {
                zoom = 1f
                pan = Offset.Zero
            }
        }
        val pinch = if (full) {
            Modifier.pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.size >= 2) {
                            val z = event.calculateZoom()
                            val p = event.calculatePan()
                            if (z != 1f || p != Offset.Zero) {
                                zoom = (zoom * z).coerceIn(0.4f, 4f)
                                pan = if (zoom > 1f) pan + p else Offset.Zero
                                event.changes.forEach { it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
        } else {
            Modifier
        }
        Box(
            box.background(Color.Black).then(pinch).doubleTapSeek({ ready && !menuOpen }, doSeek).clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
            if (ready) {
                AndroidView(
                    factory = { c ->
                        PlayerView(c).apply {
                            this.player = player
                            useController = true
                            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                            setFullscreenButtonClickListener { toFull -> fullscreen = toFull }
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = pan.x, translationY = pan.y)
                )
                // ওপরের ডানে: 🔁 বারবার চালানো, ⏭ পরের ভিডিও, ⚙ ভিডিওর মান/ধরন (আবার চাপলে লুকায়)
                Column(
                    Modifier.align(Alignment.TopEnd).padding(6.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OverlayBtn(if (repeatOne) "🔂" else "🔁", repeatOne) {
                            player.repeatMode = if (repeatOne) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
                            Toast.makeText(
                                ctx,
                                if (repeatOne) "বারবার চালানো বন্ধ" else "🔂 এই ভিডিও বারবার চলবে",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        OverlayBtn("⏭", false) {
                            Video.fullscreenCarry = fullscreen
                            if (!vm.playNextVideo(related)) {
                                Video.fullscreenCarry = false
                                Toast.makeText(ctx, "পরের ভিডিও এখনো পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                            }
                        }
                        if (qualityLabels.isNotEmpty()) {
                            OverlayBtn("⚙", false) { menuOpen = !menuOpen }
                        }
                    }
                    if (menuOpen && qualityLabels.isNotEmpty()) {
                        Column(
                            Modifier
                                .padding(top = 6.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xE6202020))
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                "ভিডিওর মান ও ধরন", color = Color(0xFFBBBBBB), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                            )
                            qualityLabels.forEachIndexed { i, label ->
                                Text(
                                    label + if (i == qualityIdx) "  ✓" else "",
                                    color = if (i == qualityIdx) Color(0xFFFDE68A) else Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = if (i == qualityIdx) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            menuOpen = false
                                            Video.runner?.switchTo(i)
                                        }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
                // দুইবার চাপলে কত সেকেন্ড গেল তার চিহ্ন
                if (seekFlash != 0) {
                    Text(
                        (if (seekFlash > 0) "⏩ +" else "⏪ −") + kotlin.math.abs(seekFlash) + " সেকেন্ড",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier
                            .align(if (seekFlash > 0) Alignment.CenterEnd else Alignment.CenterStart)
                            .padding(horizontal = 24.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0x99000000))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            } else if (status == "লোড হচ্ছে…") {
                CircularProgressIndicator(color = t.accent)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(status, color = Color.White)
                    if (retryable) {
                        Text(
                            "🔄 আবার চেষ্টা করুন", color = Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(top = 12.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0x55FFFFFF))
                                .clickable {
                                    Repo.invalidate(video.url)
                                    attempt++
                                }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
        if (!full) {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Text(video.title, color = t.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 24.sp)
                        val metaParts = listOfNotNull(
                            if (viewCount > 0) "${fmtCount(viewCount)} বার দেখা" else null,
                            video.uploadedText.ifEmpty { null }
                        )
                        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(metaParts.joinToString(" • "), color = t.muted, fontSize = 12.5.sp)
                            if (desc.isNotBlank()) {
                                Text(
                                    if (showDesc) "  …কম" else "  …আরও", color = t.text, fontWeight = FontWeight.Bold, fontSize = 12.5.sp,
                                    modifier = Modifier.clickable { showDesc = !showDesc }
                                )
                            }
                        }
                        if (showDesc && desc.isNotBlank()) {
                            Text(desc.take(1200), color = t.muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                        val name = channelName.ifEmpty { video.channel }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    // চ্যানেলের পাতা: ভিডিও ছোট হয়ে ভেসে থাকে
                                    vm.minimizePlayer()
                                    vm.openChannel(channelUrlS, name, channelIcon)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(t.accent),
                                contentAlignment = Alignment.Center
                            ) {
                                if (channelIcon != null) {
                                    AsyncImage(
                                        model = channelIcon, contentDescription = null,
                                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(name.trimStart('@').take(1).ifEmpty { "?" }, color = t.onAccent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    name.ifEmpty { "চ্যানেলের নাম পাওয়া যায়নি" },
                                    color = t.text, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                if (subs >= 0) {
                                    Text("${fmtCount(subs)} সাবস্ক্রাইবার", color = t.muted, fontSize = 12.sp)
                                }
                            }
                            val subbed = vm.isSubscribed(channelUrlS)
                            Text(
                                if (subbed) "✓ সাবস্ক্রাইব করা" else "সাবস্ক্রাইব",
                                color = if (subbed) t.text else Color.White,
                                fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (subbed) t.line else Color(0xFFFF0000))
                                    .clickable(enabled = channelUrlS.isNotEmpty()) {
                                        vm.toggleSub(ChannelRef(channelUrlS, name, channelIcon))
                                    }
                                    .padding(horizontal = 16.dp, vertical = 9.dp)
                            )
                        }
                        Row(Modifier.padding(top = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionChip(if (likeCount >= 0) "👍 ${fmtCount(likeCount)}" else "👍 পছন্দ", liked, t) { vm.toggleLike(video) }
                            ActionChip(if (dislikeCount >= 0) "👎 ${fmtCount(dislikeCount)}" else "👎", vm.isDisliked(video), t) { vm.toggleDislike(video) }
                            ActionChip("↗ শেয়ার", false, t) {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, video.title)
                                    putExtra(Intent.EXTRA_TEXT, video.title + "\n" + video.url)
                                }
                                ctx.startActivity(Intent.createChooser(send, "শেয়ার করুন"))
                            }
                            ActionChip(if (saved) "🔖 সংরক্ষিত" else "🔖 সংরক্ষণ", saved, t) { vm.toggleSave(video) }
                            val label = when {
                                dl == null -> "⬇ ডাউনলোড"
                                dlPct == null || dlPct in 0..99 -> "⏹ বন্ধ করুন (${dlPct ?: 0}%)"
                                dlPct == 100 -> "✅ ডাউনলোড হয়েছে"
                                else -> "⚠ ব্যর্থ, আবার করুন"
                            }
                            ActionChip(label, dlPct == 100, t) {
                                if (dl == null) {
                                    val u = dlUrl
                                    if (u == null) {
                                        Toast.makeText(ctx, "এই ভিডিওর ডাউনলোড লিংক পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                                    } else {
                                        vm.startDownload(video, u)
                                        Toast.makeText(ctx, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show()
                                    }
                                } else if (dlPct != null && dlPct < 0) {
                                    vm.deleteDownload(dl)
                                    val u = dlUrl
                                    if (u != null) vm.startDownload(video, u)
                                } else if (dlPct == null || dlPct in 0..99) {
                                    vm.cancelDownload(dl)
                                }
                            }
                        }
                    }
                }
                item {
                    CommentsBox(
                        t, comments, commentsMsg, showAllComments, moreLoading, commentNext != null,
                        onToggle = { showAllComments = !showAllComments },
                        onMore = {
                            val ci = commentInfo
                            val pg = commentNext
                            if (ci != null && pg != null && !moreLoading) {
                                scope.launch {
                                    moreLoading = true
                                    try {
                                        val cp = withContext(Dispatchers.IO) { Repo.moreComments(ci, pg) }
                                        comments = comments + cp.items.filter(okComment)
                                        commentNext = cp.next
                                    } catch (e: Exception) {
                                        commentNext = null
                                    } finally {
                                        moreLoading = false
                                    }
                                }
                            }
                        }
                    )
                }
                if (related.isNotEmpty()) {
                    item {
                        Text("আরও দেখুন", color = t.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                items(related) { r -> VideoCard(r, t) { vm.playVideo(r, related) } }
            }
        }
    }
}

@Composable
private fun OverlayBtn(label: String, on: Boolean, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 18.sp,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (on) Color(0xCC1E88E5) else Color(0x66000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun ActionChip(label: String, on: Boolean, t: YtTheme, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        label,
        color = if (on) t.onAccent else t.text,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(shape)
            .background(if (on) t.chipOn else t.panel)
            .border(1.dp, if (on) t.chipOn else t.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun CommentsBox(
    t: YtTheme,
    comments: List<CommentItem>,
    msg: String,
    showAll: Boolean,
    moreLoading: Boolean,
    hasMore: Boolean,
    onToggle: () -> Unit,
    onMore: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(t.panel)
            .border(1.dp, t.line, shape)
            .padding(12.dp)
    ) {
        // লেখায় চাপলে মন্তব্য খোলে, আবার চাপলে লুকিয়ে যায়
        Text(
            if (showAll) "💬 মন্তব্য লুকান ▴" else "💬 মন্তব্য দেখুন ▾",
            color = t.text, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onToggle)
                .padding(vertical = 4.dp)
        )
        if (showAll) {
            if (msg.isNotEmpty()) {
                Text(msg, color = t.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
            for (c in comments) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(t.accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(c.author.trimStart('@').take(1).ifEmpty { "?" }, color = t.onAccent, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            c.author + if (c.date.isNotEmpty()) "  ·  " + c.date else "",
                            color = t.muted, fontSize = 11.5.sp, maxLines = 1
                        )
                        Text(
                            c.text, color = t.text, fontSize = 13.5.sp,
                            maxLines = 12,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        if (c.likes > 0) {
                            Text("👍 ${c.likes}", color = t.muted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
            if (comments.isNotEmpty() && hasMore) {
                TextButton(onClick = onMore, modifier = Modifier.padding(top = 6.dp)) {
                    Text(if (moreLoading) "আসছে…" else "আরও মন্তব্য", color = t.chipOn)
                }
            }
        }
    }
}

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
