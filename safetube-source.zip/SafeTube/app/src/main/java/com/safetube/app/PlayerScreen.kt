package com.safetube.app

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(video: VideoItem, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var status by remember { mutableStateOf("লোড হচ্ছে…") }
    var ready by remember { mutableStateOf(false) }
    var desc by remember { mutableStateOf("") }

    DisposableEffect(Unit) { onDispose { player.release() } }

    LaunchedEffect(video.url) {
        try {
            val info = withContext(Dispatchers.IO) { Repo.streamInfo(video.url) }
            val d = try { info.description?.content ?: "" } catch (e: Exception) { "" }
            if (ContentFilter.isStrongBad(video.title + " " + info.uploaderName + " " + d.take(600))) {
                status = "এই ভিডিও এখানে চালানো যাবে না।"
                return@LaunchedEffect
            }
            desc = d
            val src = withContext(Dispatchers.IO) { Repo.buildSource(info) }
            if (src == null) {
                status = "এই ভিডিওর চালানোর মতো লিংক পাওয়া যায়নি।"
                return@LaunchedEffect
            }
            player.setMediaSource(src)
            player.prepare()
            player.playWhenReady = true
            ready = true
        } catch (e: Exception) {
            status = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
    ) {
        val box = if (landscape) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        Box(box.background(androidx.compose.ui.graphics.Color.Black), contentAlignment = Alignment.Center) {
            if (ready) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { this.player = player; useController = true } },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (status == "লোড হচ্ছে…") {
                CircularProgressIndicator(color = Accent)
            } else {
                Text(status, color = Muted, modifier = Modifier.padding(16.dp))
            }
        }
        if (!landscape) {
            Column(Modifier.padding(16.dp)) {
                Text(video.title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Text(video.channel, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                TextButton(onClick = onBack, modifier = Modifier.padding(top = 8.dp)) { Text("← ফিরে যান") }
            }
        }
    }
}
