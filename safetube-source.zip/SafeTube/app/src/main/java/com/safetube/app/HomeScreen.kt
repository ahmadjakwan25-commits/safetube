package com.safetube.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val TOPICS = listOf("কুরআন তিলাওয়াত", "ওয়াজ", "দোয়া", "ইসলামিক জ্ঞান", "হাদিস", "সীরাত")

fun fmtDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
fun HomeScreen(vm: MainVm) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("খুঁজুন…") },
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search() })
            )
            TextButton(onClick = { vm.search() }) { Text("🔍", fontSize = 20.sp) }
            TextButton(onClick = { vm.showSettings = true }) { Text("⚙️", fontSize = 20.sp) }
        }

        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(TOPICS) { t ->
                AssistChip(onClick = { vm.search(t) }, label = { Text(t) })
            }
        }
        Spacer(Modifier.padding(top = 8.dp))

        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(vm.items) { v -> VideoCard(v) { vm.current = v } }
                if (vm.canLoadMore && !vm.loading) {
                    item {
                        Button(onClick = { vm.loadMore() }, modifier = Modifier.fillMaxWidth()) { Text("আরও দেখুন") }
                    }
                }
            }
            if (vm.loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = Accent)
            }
            vm.message?.let {
                Text(
                    it,
                    Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    color = Muted
                )
            }
            if (vm.items.isEmpty() && !vm.loading && vm.message == null) {
                Text(
                    "উপরের বিষয় বেছে নিন বা খুঁজুন।",
                    Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    color = Muted
                )
            }
        }
    }

    if (vm.showSettings) {
        AlertDialog(
            onDismissRequest = { vm.showSettings = false },
            confirmButton = { TextButton(onClick = { vm.showSettings = false }) { Text("ঠিক আছে") } },
            title = { Text("সেটিংস") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("শুধু ইসলামিক বিষয়", fontWeight = FontWeight.SemiBold)
                        Text("চালু থাকলে ইসলামিক শব্দ নেই এমন ভিডিও দেখাবে না।", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = vm.islamicOnly, onCheckedChange = { vm.updateIslamicOnly(it) })
                }
            }
        )
    }
}

@Composable
fun VideoCard(v: VideoItem, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Card)
            .clickable { onClick() }
    ) {
        Box {
            AsyncImage(
                model = v.thumb,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
                contentScale = ContentScale.Crop
            )
            val d = fmtDuration(v.durationSec)
            if (d.isNotEmpty()) {
                Text(
                    d,
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Bg.copy(alpha = 0.8f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    fontSize = 12.sp
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.padding(top = 4.dp))
            val views = if (v.views > 0) " · ${v.views} বার দেখা" else ""
            Text(v.channel + views, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
