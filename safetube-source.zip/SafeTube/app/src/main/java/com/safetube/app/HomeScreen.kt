package com.safetube.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val TOPICS = listOf("কুরআন তিলাওয়াত", "ওয়াজ", "দোয়া", "ইসলামিক জ্ঞান", "হাদিস", "সীরাত", "নাত", "রমজান")
private val GOLD_LINE = listOf(Color.Transparent, Color(0xFFFDE68A), Color(0xFFF6C445), Color(0xFFFDE68A), Color.Transparent)

fun fmtDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/* ---------- হেডার: চ্যাট অ্যাপের ইউটিউবের মতো সোনালি ব্যাজ + গ্রেডিয়েন্ট ---------- */

@Composable
fun HeaderBtn(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .size(38.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.2f))
            .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 17.sp, color = Color.White) }
}

@Composable
fun YtHeader(t: YtTheme, onBack: (() -> Unit)? = null, onTheme: (() -> Unit)? = null, onSettings: (() -> Unit)? = null) {
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(t.header))
                .statusBarsPadding()
        ) {
            Row(
                Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    HeaderBtn("←", onBack)
                    Spacer(Modifier.width(8.dp))
                }
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(Color(0xFFFFFBE0), Color(0xFFF6C445), Color(0xFFC98D0B)))),
                    contentAlignment = Alignment.Center
                ) { Text("🕌", fontSize = 22.sp) }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("ইসলামিক ভিডিও", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Box(
                        Modifier
                            .padding(top = 3.dp)
                            .size(width = 50.dp, height = 2.dp)
                            .background(Brush.horizontalGradient(listOf(Color(0xFFFDE68A), Color.Transparent)))
                    )
                }
                if (onTheme != null) {
                    HeaderBtn("🎨", onTheme)
                    Spacer(Modifier.width(6.dp))
                }
                if (onSettings != null) HeaderBtn("⚙️", onSettings)
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.horizontalGradient(GOLD_LINE))
        )
    }
}

/* ---------- মূল পাতা: হেডার + ট্যাব + নিচের মেনু ---------- */

@Composable
fun MainScreen(vm: MainVm) {
    val t = vm.theme
    Column(
        Modifier
            .fillMaxSize()
            .background(t.bg)
    ) {
        YtHeader(t, onTheme = { vm.showThemes = true }, onSettings = { vm.tab = Tab.SETTINGS })
        Box(Modifier.weight(1f)) {
            when (vm.tab) {
                Tab.HOME -> HomeTab(vm, t)
                Tab.SAVED -> SavedTab(vm, t)
                Tab.HISTORY -> VideoGrid(
                    vm, t, vm.history, false, null,
                    "এখনো কিছু দেখা হয়নি।", "🗑 ইতিহাস মুছুন" to { vm.clearHistory() }
                )
                Tab.DOWNLOADS -> DownloadsTab(vm, t)
                Tab.SETTINGS -> SettingsTab(vm, t)
            }
        }
        BottomBar(vm, t)
    }

    if (vm.showThemes) {
        AlertDialog(
            onDismissRequest = { vm.showThemes = false },
            confirmButton = { TextButton(onClick = { vm.showThemes = false }) { Text("বন্ধ") } },
            title = { Text("🎨 থিম বেছে নিন") },
            text = {
                LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(YT_THEMES) { th ->
                        val sel = th.id == vm.themeId
                        val shape = RoundedCornerShape(12.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(shape)
                                .background(if (sel) th.accent.copy(alpha = 0.15f) else Color.Transparent)
                                .border(1.dp, if (sel) th.accent else t.line, shape)
                                .clickable { vm.pickTheme(th.id) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(22.dp).clip(CircleShape).background(th.accent))
                            Box(Modifier.size(22.dp).clip(CircleShape).background(th.swatch2).border(1.dp, t.line, CircleShape))
                            Spacer(Modifier.width(10.dp))
                            Text(th.name, Modifier.weight(1f), fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp)
                            if (sel) Text("✓", color = th.accent, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun BottomBar(vm: MainVm, t: YtTheme) {
    val tabs = listOf(
        Triple(Tab.HOME, "🏠", "হোম"),
        Triple(Tab.SAVED, "🔖", "সংরক্ষিত"),
        Triple(Tab.DOWNLOADS, "⬇", "ডাউনলোড"),
        Triple(Tab.HISTORY, "🕘", "ইতিহাস"),
        Triple(Tab.SETTINGS, "⚙️", "সেটিংস")
    )
    Column(Modifier.fillMaxWidth().background(t.panel).navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(t.line))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)) {
            for ((tab, icon, label) in tabs) {
                val on = vm.tab == tab
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (on) t.accent.copy(alpha = 0.16f) else Color.Transparent)
                        .clickable { vm.tab = tab }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 20.sp)
                    Text(
                        label, fontSize = 11.sp, maxLines = 1,
                        color = if (on) t.chipOn else t.muted,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

/* ---------- হোম ট্যাব: সার্চ + বিষয় + নিজে নিজে আসা ভিডিও ---------- */

@Composable
fun HomeTab(vm: MainVm, t: YtTheme) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(t.panel)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("ইসলামিক ভিডিও খুঁজুন…", color = t.muted) },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = t.text,
                    unfocusedTextColor = t.text,
                    focusedContainerColor = t.bg,
                    unfocusedContainerColor = t.bg,
                    focusedBorderColor = t.accent,
                    unfocusedBorderColor = t.line,
                    cursorColor = t.accent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search() })
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(width = 46.dp, height = 52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(t.accent)
                    .clickable { vm.search() },
                contentAlignment = Alignment.Center
            ) { Text("🔍", fontSize = 19.sp, color = t.onAccent) }
        }

        LazyRow(
            Modifier
                .fillMaxWidth()
                .background(t.panel),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(listOf("") + TOPICS) { name ->
                val on = if (name.isEmpty()) !vm.showingSearch else (vm.showingSearch && vm.chip == name)
                val label = if (name.isEmpty()) "সব" else name
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier
                        .clip(shape)
                        .background(if (on) t.chipOn else t.bg)
                        .border(1.dp, if (on) t.chipOn else t.line, shape)
                        .clickable { vm.pickChip(name) }
                        .padding(start = 6.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(if (on) t.onAccent else t.accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (name.isEmpty()) "★" else name.take(1),
                            color = if (on) t.chipOn else t.onAccent,
                            fontWeight = FontWeight.ExtraBold, fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = if (on) t.onAccent else t.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(t.line))

        val searching = vm.showingSearch
        val list = if (searching) vm.items else vm.feed
        val loading = if (searching) vm.loading else vm.feedLoading
        val msg = if (searching) vm.message else vm.feedMessage
        VideoGrid(
            vm, t, list, loading,
            { if (searching) { if (vm.canLoadMore) vm.loadMore() } else vm.loadFeed() },
            msg ?: "ভিডিও আসছে…", null
        )
    }
}

/* ---------- ভিডিওর গ্রিড (হোম, সংরক্ষিত, ইতিহাস সবখানে একই) ---------- */

@Composable
fun VideoGrid(
    vm: MainVm,
    t: YtTheme,
    list: List<VideoItem>,
    loading: Boolean,
    nearEnd: (() -> Unit)?,
    emptyText: String,
    topAction: Pair<String, () -> Unit>?
) {
    val cols = if (t.layout == CardLayout.GRID || t.layout == CardLayout.MAG) 2 else 1
    val state = rememberLazyGridState()
    if (nearEnd != null) {
        LaunchedEffect(state, list.size) {
            snapshotFlow { state.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
                .collect { last ->
                    val total = state.layoutInfo.totalItemsCount
                    if (total > 0 && last >= total - 4) nearEnd()
                }
        }
    }
    Box(Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (topAction != null && list.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        TextButton(onClick = topAction.second) { Text(topAction.first, color = t.chipOn) }
                    }
                }
            }
            items(list) { v -> VideoCard(v, t) { vm.current = v } }
            if (loading && list.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = t.accent)
                    }
                }
            }
        }
        if (list.isEmpty()) {
            if (loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = t.accent)
            } else {
                Text(emptyText, Modifier.align(Alignment.Center).padding(24.dp), color = t.muted, textAlign = TextAlign.Center)
            }
        }
    }
}

/* ---------- সংরক্ষিত + পছন্দের ---------- */

@Composable
fun SavedTab(vm: MainVm, t: YtTheme) {
    var showLiked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(t.panel).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for ((label, on) in listOf("🔖 সংরক্ষিত" to !showLiked, "👍 পছন্দের" to showLiked)) {
                val shape = RoundedCornerShape(20.dp)
                Text(
                    label,
                    color = if (on) t.onAccent else t.text,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(shape)
                        .background(if (on) t.chipOn else t.bg)
                        .border(1.dp, if (on) t.chipOn else t.line, shape)
                        .clickable { showLiked = label.startsWith("👍") }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(t.line))
        if (showLiked) {
            VideoGrid(vm, t, vm.liked, false, null, "কোনো ভিডিওতে 👍 দেওয়া হয়নি।", null)
        } else {
            VideoGrid(vm, t, vm.saved, false, null, "কিছু সংরক্ষণ করা হয়নি।\nভিডিও চালিয়ে 🔖 চাপলে এখানে জমা হবে।", null)
        }
    }
}

/* ---------- ডাউনলোড ট্যাব ---------- */

@Composable
fun DownloadsTab(vm: MainVm, t: YtTheme) {
    LaunchedEffect(Unit) {
        while (true) {
            vm.refreshDownloads()
            delay(1500)
        }
    }
    if (vm.downloads.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "কিছু ডাউনলোড করা নেই।\nভিডিও চালিয়ে ⬇ চাপলে এখানে আসবে।",
                color = t.muted, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp)
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(vm.downloads) { d ->
            val pct = vm.dlProgress[d.dlId] ?: 0
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(t.panel)
                    .border(1.dp, t.line, shape)
                    .clickable(enabled = pct == 100) { vm.current = d.video }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = d.video.thumb, contentDescription = null,
                    modifier = Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
                Column(Modifier.weight(1f)) {
                    Text(d.video.title, color = t.text, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        when {
                            pct == 100 -> "✅ ডাউনলোড হয়েছে — চাপলে চলবে"
                            pct < 0 -> "⚠ ব্যর্থ হয়েছে"
                            else -> "⏳ নামছে… $pct%"
                        },
                        color = if (pct < 0) Color(0xFFE53935) else t.muted, fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                TextButton(onClick = { vm.deleteDownload(d) }) { Text("🗑", fontSize = 20.sp) }
            }
        }
    }
}

/* ---------- সেটিংস ট্যাব ---------- */

@Composable
fun SettingsTab(vm: MainVm, t: YtTheme) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clip(shape).background(t.panel).border(1.dp, t.line, shape).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("শুধু ইসলামিক বিষয়", color = t.text, fontWeight = FontWeight.Bold)
                Text("চালু থাকলে ইসলামিক শব্দ নেই এমন ভিডিও দেখাবে না।", color = t.muted, fontSize = 12.sp)
            }
            Switch(checked = vm.islamicOnly, onCheckedChange = { vm.updateIslamicOnly(it) })
        }
        SettingsRow("🎨 থিম বদলান", "১৪টি থিমের একটি বেছে নিন", t) { vm.showThemes = true }
        SettingsRow("🔄 হোমের ভিডিও নতুন করে আনুন", "পছন্দের ধরন দেখে নতুন তালিকা বানাবে", t) {
            vm.tab = Tab.HOME
            vm.refreshFeed()
        }
        SettingsRow("🗑 ইতিহাস মুছুন", "দেখার তালিকা পরিষ্কার হবে (সংরক্ষিত থাকবে)", t) { vm.clearHistory() }
        Text(
            "নিরাপদ টিউব — খারাপ বা অনৈসলামিক কনটেন্ট আটকানো ফিল্টারসহ ইউটিউব ক্লায়েন্ট।\nসংরক্ষিত, ইতিহাস আর ডাউনলোড শুধু এই ফোনে থাকে।",
            color = t.muted, fontSize = 12.sp, modifier = Modifier.padding(4.dp)
        )
    }
}

@Composable
private fun SettingsRow(title: String, sub: String, t: YtTheme, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(t.panel).border(1.dp, t.line, shape).clickable(onClick = onClick).padding(14.dp)
    ) {
        Text(title, color = t.text, fontWeight = FontWeight.Bold)
        Text(sub, color = t.muted, fontSize = 12.sp)
    }
}

/* ---------- ভিডিও কার্ড ---------- */

@Composable
fun VideoCard(v: VideoItem, t: YtTheme, onClick: () -> Unit) {
    val hue = (((v.channel.hashCode() % 360) + 360) % 360).toFloat()
    val h1 = Color.hsl(hue, 0.75f, 0.48f)
    when (t.layout) {
        CardLayout.MAG -> MagCard(v, onClick)
        CardLayout.CINEMA -> CinemaCard(v, onClick)
        CardLayout.LIST -> FrameCard(v, t, h1, true, onClick)
        CardLayout.GRID -> FrameCard(v, t, h1, false, onClick)
    }
}

@Composable
private fun Thumb(v: VideoItem, modifier: Modifier, border: Pair<Dp, Color>?, shape: Shape) {
    var m = modifier.aspectRatio(16f / 9f).clip(shape)
    if (border != null) m = m.border(border.first, border.second, shape)
    AsyncImage(model = v.thumb, contentDescription = null, modifier = m, contentScale = ContentScale.Crop)
}

@Composable
private fun Tag(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Text(
        text, color = fg, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = modifier.clip(RoundedCornerShape(12.dp)).background(bg).padding(horizontal = 8.dp, vertical = 1.dp)
    )
}

@Composable
private fun Tags(v: VideoItem, bg: Color, fg: Color, center: Boolean = false) {
    val second = listOfNotNull(
        fmtDuration(v.durationSec).ifEmpty { null },
        if (v.views > 0) "${v.views} বার" else null
    ).joinToString(" · ")
    Row(
        Modifier.fillMaxWidth().padding(top = 4.dp),
        horizontalArrangement = if (center) Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally) else Arrangement.spacedBy(4.dp)
    ) {
        if (v.channel.isNotEmpty()) Tag(v.channel, bg, fg, Modifier.weight(1f, fill = false))
        if (second.isNotEmpty()) Tag(second, bg, fg)
    }
}

@Composable
private fun FrameCard(v: VideoItem, t: YtTheme, h1: Color, row: Boolean, onClick: () -> Unit) {
    val d = t.deco
    val shape: Shape = when (d) {
        Deco.ARCH -> RoundedCornerShape(20.dp, 20.dp, 14.dp, 14.dp)
        Deco.PAPER -> RoundedCornerShape(6.dp)
        else -> RoundedCornerShape(14.dp)
    }
    val imgShape: Shape = when (d) {
        Deco.ARCH -> RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp, bottomEnd = 10.dp, bottomStart = 10.dp)
        Deco.PAPER -> RoundedCornerShape(3.dp)
        else -> RoundedCornerShape(10.dp)
    }
    val bar: Color? = when (d) {
        Deco.HUE -> h1
        Deco.GOLD -> Color(0xFFD4A017)
        Deco.NEON -> Color(0xFF22D3EE)
        else -> null
    }
    val borderCol: Color = when (d) {
        Deco.HUE -> h1.copy(alpha = 0.5f)
        Deco.PLAIN -> Color.Transparent
        Deco.GOLD -> Color(0xFFF0E1B8)
        Deco.NEON -> Color(0x8C22D3EE)
        Deco.ARCH -> Color(0xFFD4A017)
        Deco.PAPER -> Color(0xFFB08D57)
    }
    val borderW: Dp = when (d) {
        Deco.ARCH -> 2.dp
        Deco.PAPER -> 1.5.dp
        Deco.PLAIN -> 0.dp
        else -> 1.dp
    }
    val bg: Brush = when (d) {
        Deco.ARCH -> Brush.verticalGradient(listOf(Color(0xFFFFFDF5), Color(0xFFF7EFD2)))
        Deco.PAPER -> SolidColor(Color(0xFFFFFAF0))
        Deco.NEON -> SolidColor(t.panel.copy(alpha = 0.75f))
        Deco.HUE -> Brush.horizontalGradient(listOf(h1.copy(alpha = 0.22f).compositeOver(t.panel), t.panel))
        else -> SolidColor(t.panel)
    }
    val tagBg: Color
    val tagFg: Color
    when (d) {
        Deco.HUE -> { tagBg = h1.copy(alpha = 0.18f); tagFg = t.text }
        Deco.GOLD, Deco.ARCH -> { tagBg = Color(0xFFFDF1CF); tagFg = Color(0xFF6B4E0A) }
        Deco.NEON -> { tagBg = Color(0x2422D3EE); tagFg = Color(0xFFBFF6FF) }
        Deco.PAPER -> { tagBg = Color(0xFFEFE0BF); tagFg = Color(0xFF5E4520) }
        Deco.PLAIN -> { tagBg = Color(0xFFF2F2F2); tagFg = t.muted }
    }
    val imgBorder: Pair<Dp, Color>? = when (d) {
        Deco.HUE -> 2.dp to h1
        Deco.ARCH -> 2.dp to Color(0xFFD4A017)
        Deco.NEON -> 1.dp to Color(0x9922D3EE)
        Deco.PAPER -> 3.dp to Color.White
        else -> null
    }

    var mod = Modifier.fillMaxWidth().clip(shape).background(bg)
    if (borderW > 0.dp) mod = mod.border(borderW, borderCol, shape)
    if (bar != null) mod = mod.drawBehind { drawRect(bar, size = Size(6.dp.toPx(), size.height)) }
    mod = mod.clickable(onClick = onClick)
        .padding(start = if (bar != null) 12.dp else 6.dp, top = 6.dp, end = 6.dp, bottom = 6.dp)

    val center = d == Deco.ARCH
    if (row) {
        Row(mod, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(v, Modifier.width(132.dp), imgBorder, imgShape)
            Column(Modifier.weight(1f)) {
                Text(v.title, color = t.text, fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Tags(v, tagBg, tagFg)
            }
        }
    } else {
        Column(mod) {
            Thumb(v, Modifier.fillMaxWidth(), imgBorder, imgShape)
            Text(
                v.title, color = t.text, fontSize = 13.5.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
                textAlign = if (center) TextAlign.Center else TextAlign.Start,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            Tags(v, tagBg, tagFg, center)
        }
    }
}

@Composable
private fun CinemaCard(v: VideoItem, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFF141414)).clickable(onClick = onClick)) {
        AsyncImage(
            model = v.thumb, contentDescription = null,
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
            contentScale = ContentScale.Crop
        )
        Column(Modifier.padding(start = 13.dp, end = 13.dp, top = 11.dp, bottom = 14.dp)) {
            Text(v.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Tags(v, Color(0xFF262626), Color(0xFFCCCCCC))
        }
    }
}

@Composable
private fun MagCard(v: VideoItem, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(Modifier.fillMaxWidth().aspectRatio(4f / 3f).clip(shape).background(Color(0xFF111111)).clickable(onClick = onClick)) {
        AsyncImage(model = v.thumb, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE0000000))))
                .padding(start = 10.dp, end = 10.dp, top = 34.dp, bottom = 9.dp)
        ) {
            Text(v.title, color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Tags(v, Color(0x33FFFFFF), Color.White)
        }
    }
}
