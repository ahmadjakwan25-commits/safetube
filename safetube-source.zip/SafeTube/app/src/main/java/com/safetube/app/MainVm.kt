package com.safetube.app

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler

enum class Tab { HOME, SAVED, DOWNLOADS, HISTORY, SETTINGS }

class MainVm(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("safetube", Context.MODE_PRIVATE)
    private val store = Store(app)

    var tab by mutableStateOf(Tab.HOME)
    var current by mutableStateOf<VideoItem?>(null)
    var showThemes by mutableStateOf(false)

    // থিম
    var themeId by mutableStateOf(prefs.getString("ytTheme", "default") ?: "default")
        private set
    val theme: YtTheme get() = YT_THEMES.firstOrNull { it.id == themeId } ?: YT_THEMES[0]
    fun pickTheme(id: String) {
        themeId = id
        prefs.edit().putString("ytTheme", id).apply()
    }

    // ফিল্টার: কঠোর স্ক্রিনিং সবসময় চালু, বন্ধ করার কোনো উপায় নেই
    val islamicOnly: Boolean = true

    fun keep(v: VideoItem): Boolean = ContentFilter.textScore(v.title + " " + v.channel) >= 1

    // সার্চ
    var query by mutableStateOf("")
    var items by mutableStateOf<List<VideoItem>>(emptyList())
    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var showingSearch by mutableStateOf(false)
    var chip by mutableStateOf("")
    var canLoadMore by mutableStateOf(false)
        private set

    private var handler: SearchQueryHandler? = null
    private var nextPage: Page? = null
    private var job: Job? = null

    fun pickChip(name: String) {
        if (name.isEmpty()) {
            if (showingSearch) {
                showingSearch = false
                chip = ""
                query = ""
            } else {
                refreshFeed()
            }
        } else {
            chip = name
            query = name
            search(name)
        }
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return
        query = text
        if (text != chip) chip = ""
        showingSearch = true
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            message = null
            items = emptyList()
            canLoadMore = false
            handler = null
            nextPage = null
            try {
                if (ContentFilter.isBad(text)) {
                    message = "এই বিষয়টি এখানে খোঁজা যায় না।"
                    return@launch
                }
                val first = withContext(Dispatchers.IO) { Repo.search(text) }
                handler = first.handler
                nextPage = first.next
                val found = first.items.filter { keep(it) }.toMutableList()
                var tries = 0
                while (found.size < 10 && nextPage != null && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(handler!!, nextPage!!) }
                    nextPage = more.next
                    found += more.items.filter { keep(it) }
                    tries++
                }
                items = found
                canLoadMore = nextPage != null
                if (found.isEmpty()) message = "কিছু পাওয়া যায়নি।"
            } catch (e: Exception) {
                message = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
            }
        }
    }

    fun loadMore() {
        val h = handler ?: return
        val p = nextPage ?: return
        if (loading) return
        job = viewModelScope.launch {
            loading = true
            try {
                val found = mutableListOf<VideoItem>()
                var page: Page? = p
                var tries = 0
                while (page != null && found.size < 10 && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(h, page!!) }
                    page = more.next
                    found += more.items.filter { keep(it) }
                    tries++
                }
                nextPage = page
                items = items + found
                canLoadMore = page != null
            } catch (e: Exception) {
                message = "আরও আনা যায়নি: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
            }
        }
    }

    // হোমের নিজে নিজে আসা ভিডিও
    val feed = mutableStateListOf<VideoItem>()
    var feedLoading by mutableStateOf(false)
    var feedMessage by mutableStateOf<String?>(null)
    private val feedQueue = ArrayDeque<String>()
    private val seen = HashSet<String>()
    private var feedJob: Job? = null
    private val feedBase = TOPICS + listOf("ইসলামিক গজল", "হজ্জ ও ওমরাহ", "নবীদের কাহিনী", "তাফসীর", "জুমার খুতবা")

    private fun refillQueue() {
        feedQueue.clear()
        history.map { it.channel }.filter { it.isNotEmpty() }.distinct().take(3).forEach { feedQueue.addLast(it) }
        feedBase.shuffled().forEach { feedQueue.addLast(it) }
    }

    fun refreshFeed() {
        feedJob?.cancel()
        feed.clear()
        seen.clear()
        feedQueue.clear()
        feedMessage = null
        feedLoading = false
        loadFeed()
    }

    fun loadFeed() {
        if (feedLoading) return
        feedJob = viewModelScope.launch {
            feedLoading = true
            try {
                var added = 0
                var tries = 0
                while (added < 8 && tries < 4) {
                    if (feedQueue.isEmpty()) refillQueue()
                    val q = feedQueue.removeFirst()
                    tries++
                    val page = runCatching { withContext(Dispatchers.IO) { Repo.search(q) } }.getOrNull() ?: continue
                    for (v in page.items) {
                        if (keep(v) && seen.add(v.url)) {
                            feed.add(v)
                            added++
                        }
                    }
                }
                feedMessage = if (feed.isEmpty()) "ভিডিও আনা যায়নি। ইন্টারনেট দেখে 'সব' চেপে আবার চেষ্টা করুন।" else null
            } finally {
                feedLoading = false
            }
        }
    }

    // সংরক্ষিত
    val saved = mutableStateListOf<VideoItem>()
    fun isSaved(v: VideoItem): Boolean = saved.any { it.url == v.url }
    fun toggleSave(v: VideoItem) {
        val i = saved.indexOfFirst { it.url == v.url }
        if (i >= 0) saved.removeAt(i) else saved.add(0, v)
        store.saveVideos("saved", saved)
    }

    // পছন্দের (👍) ভিডিও — শুধু এই ফোনে
    val liked = mutableStateListOf<VideoItem>()
    fun isLiked(v: VideoItem): Boolean = liked.any { it.url == v.url }
    fun toggleLike(v: VideoItem) {
        val i = liked.indexOfFirst { it.url == v.url }
        if (i >= 0) liked.removeAt(i) else liked.add(0, v)
        store.saveVideos("liked", liked)
    }

    // ইতিহাস
    val history = mutableStateListOf<VideoItem>()
    fun addHistory(v: VideoItem) {
        history.removeAll { it.url == v.url }
        history.add(0, v)
        while (history.size > 200) history.removeAt(history.size - 1)
        store.saveVideos("history", history)
    }

    fun clearHistory() {
        history.clear()
        store.saveVideos("history", history)
    }

    // ডাউনলোড
    val downloads = mutableStateListOf<DlItem>()
    val dlProgress = mutableStateMapOf<Long, Int>()

    private fun dm(): DownloadManager = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun startDownload(v: VideoItem, url: String): Boolean {
        if (downloads.any { it.video.url == v.url }) return false
        val name = "v" + (v.url.hashCode().toLong() and 0xffffffffL) + ".mp4"
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(v.title)
            .setDescription("নিরাপদ টিউব")
            .addRequestHeader("User-Agent", USER_AGENT)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, Environment.DIRECTORY_MOVIES, name)
        val id = dm().enqueue(req)
        val dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        val path = File(dir, name).absolutePath
        downloads.add(0, DlItem(v, id, path))
        store.saveDownloads(downloads)
        dlProgress[id] = 0
        return true
    }

    fun refreshDownloads() {
        for (d in downloads.toList()) {
            var pct = -1
            try {
                val c = dm().query(DownloadManager.Query().setFilterById(d.dlId))
                c?.use {
                    if (it.moveToFirst()) {
                        val st = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val got = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        pct = when (st) {
                            DownloadManager.STATUS_SUCCESSFUL -> 100
                            DownloadManager.STATUS_FAILED -> -1
                            else -> if (total > 0) ((got * 100) / total).toInt().coerceIn(0, 99) else 0
                        }
                    } else if (File(d.path).exists()) {
                        pct = 100
                    }
                }
            } catch (e: Exception) {
                if (File(d.path).exists()) pct = 100
            }
            if (dlProgress[d.dlId] != pct) dlProgress[d.dlId] = pct
        }
    }

    fun deleteDownload(d: DlItem) {
        try { dm().remove(d.dlId) } catch (e: Exception) { }
        try { File(d.path).delete() } catch (e: Exception) { }
        downloads.removeAll { it.dlId == d.dlId }
        dlProgress.remove(d.dlId)
        store.saveDownloads(downloads)
    }

    /** ডাউনলোড সম্পূর্ণ হলে ফাইলের পথ, নইলে null */
    fun localFile(v: VideoItem): String? {
        val d = downloads.firstOrNull { it.video.url == v.url } ?: return null
        return if ((dlProgress[d.dlId] ?: 0) == 100 && File(d.path).exists()) d.path else null
    }

    init {
        saved.addAll(store.loadVideos("saved"))
        liked.addAll(store.loadVideos("liked"))
        history.addAll(store.loadVideos("history"))
        downloads.addAll(store.loadDownloads())
        refreshDownloads()
        loadFeed()
    }
}
