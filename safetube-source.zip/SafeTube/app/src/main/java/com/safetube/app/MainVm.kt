package com.safetube.app

import android.app.Application
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler

enum class Tab { HOME, SHORTS, MUSIC, LIBRARY, SETTINGS }

val MUSIC_TOPICS = listOf("ইসলামিক গজল", "নাত", "হামদ", "নাশিদ", "কুরআন তিলাওয়াত", "কাসিদা", "দোয়া")

class MainVm(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("safetube", Context.MODE_PRIVATE)
    private val store = Store(app)

    var tab by mutableStateOf(Tab.HOME)
    var current by mutableStateOf<VideoItem?>(null)
    var showThemes by mutableStateOf(false)
    var showProfile by mutableStateOf(false)

    // থিম
    var themeId by mutableStateOf(initialTheme())
        private set

    // নতুন সংস্করণ প্রথমবার খুললে ইউটিউব থিম বসে যায়; এরপর আপনার বাছাই মনে থাকে
    private fun initialTheme(): String {
        if (!prefs.getBoolean("ytxApplied", false)) {
            prefs.edit().putString("ytTheme", "ytx").putBoolean("ytxApplied", true).apply()
            return "ytx"
        }
        return prefs.getString("ytTheme", "ytx") ?: "ytx"
    }
    val theme: YtTheme get() = YT_THEMES.firstOrNull { it.id == themeId } ?: YT_THEMES[0]
    fun pickTheme(id: String) {
        themeId = id
        prefs.edit().putString("ytTheme", id).apply()
    }

    // ফিল্টার: কঠোর স্ক্রিনিং সবসময় চালু, বন্ধ করার কোনো উপায় নেই
    val islamicOnly: Boolean = true

    fun keep(v: VideoItem): Boolean = ContentFilter.textScore(v.title + " " + v.channel) >= 1

    // ভ্রমণ/প্রকৃতির সার্চে ইসলামিক শব্দ ছাড়াও (বিনোদন ছাড়া) ভিডিও দেখানো হয়
    private var searchIntent = false
    private val travelOk = HashSet<String>()

    private fun keepSearch(v: VideoItem): Boolean {
        if (!searchIntent) return keep(v)
        val ok = ContentFilter.textScore(v.title + " " + v.channel) >= 0
        if (ok) travelOk.add(v.url)
        return ok
    }

    fun screenStrict(v: VideoItem): Boolean = islamicOnly && !travelOk.contains(v.url)

    // টেনে নতুন ভিডিও আনা
    var pulling by mutableStateOf(false)

    fun pullRefresh() {
        pulling = true
        if (showingSearch && query.isNotBlank()) search(query) else refreshFeed()
    }

    // সার্চ
    var query by mutableStateOf("")
    var items by mutableStateOf<List<VideoItem>>(emptyList())
    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var showingSearch by mutableStateOf(false)
    var chip by mutableStateOf("")
    var canLoadMore by mutableStateOf(false)
        private set

    private var handler: SearchQueryHandler? = null
    private var nextPage: Page? = null
    private var job: Job? = null

    fun pickChip(name: String) {
        if (name.isEmpty()) {
            if (showingSearch) {
                showingSearch = false
                chip = ""
                query = ""
            } else {
                refreshFeed()
            }
        } else {
            chip = name
            query = name
            search(name)
        }
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return
        query = text
        if (text != chip) chip = ""
        showingSearch = true
        searchIntent = ContentFilter.topicScore(text) >= 1
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            message = null
            items = emptyList()
            canLoadMore = false
            handler = null
            nextPage = null
            try {
                if (ContentFilter.isBad(text)) {
                    message = "এই বিষয়টি এখানে খোঁজা যায় না।"
                    return@launch
                }
                val first = withContext(Dispatchers.IO) { Repo.search(text) }
                handler = first.handler
                nextPage = first.next
                val found = first.items.filter { keepSearch(it) }.toMutableList()
                var tries = 0
                while (found.size < 10 && nextPage != null && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(handler!!, nextPage!!) }
                    nextPage = more.next
                    found += more.items.filter { keepSearch(it) }
                    tries++
                }
                items = found
                canLoadMore = nextPage != null
                if (found.isEmpty()) message = "কিছু পাওয়া যায়নি।"
            } catch (e: Exception) {
                message = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
                pulling = false
            }
        }
    }

    fun loadMore() {
        val h = handler ?: return
        val p = nextPage ?: return
        if (loading) return
        job = viewModelScope.launch {
            loading = true
            try {
                val found = mutableListOf<VideoItem>()
                var page: Page? = p
                var tries = 0
                while (page != null && found.size < 10 && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(h, page!!) }
                    page = more.next
                    found += more.items.filter { keepSearch(it) }
                    tries++
                }
                nextPage = page
                items = items + found
                canLoadMore = page != null
            } catch (e: Exception) {
                message = "আরও আনা যায়নি: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
            }
        }
    }

    // হোমের নিজে নিজে আসা ভিডিও
    val feed = mutableStateListOf<VideoItem>()
    var feedLoading by mutableStateOf(false)
    var feedMessage by mutableStateOf<String?>(null)
    private val feedQueue = ArrayDeque<String>()
    private val seen = HashSet<String>()
    private var feedJob: Job? = null
    private var feedGen = 0
    private val feedBase = TOPICS + listOf("ইসলামিক গজল", "হজ্জ ও ওমরাহ", "নবীদের কাহিনী", "তাফসীর", "জুমার খুতবা")

    // আগে একবার দেখানো ভিডিও (এই চালুর সময়ে) টেনে নতুন করে আনলে আর আসবে না
    private val shownEver = HashSet<String>()
    private val feedSuffix = listOf("", " নতুন", " ২০২৬", " সর্বশেষ", " বাংলা", " সম্পূর্ণ", " পর্ব")

    private fun refillQueue() {
        feedQueue.clear()
        history.map { it.channel }.filter { it.isNotEmpty() }.distinct().shuffled().take(3).forEach { feedQueue.addLast(it) }
        // একই বিষয়ে একটু আলাদা শব্দ জুড়ে, যাতে প্রতিবার আলাদা ফলাফল আসে
        feedBase.shuffled().forEach { feedQueue.addLast(it + feedSuffix.random()) }
    }

    /** একসাথে ৩টা সার্চ চালায় (আগে একটা একটা করে চলত, তাই ধীর ছিল) */
    private suspend fun feedPass(ignoreShown: Boolean, target: MutableList<VideoItem> = feed): Int {
        var added = 0
        var rounds = 0
        while (added < 8 && rounds < 3) {
            rounds++
            val qs = mutableListOf<String>()
            repeat(3) {
                if (feedQueue.isEmpty()) refillQueue()
                qs.add(feedQueue.removeFirst())
            }
            val jobs = qs.map { q ->
                viewModelScope.async(Dispatchers.IO) { runCatching { Repo.search(q) }.getOrNull() }
            }
            for (j in jobs) {
                val page = j.await() ?: continue
                for (v in page.items) {
                    if (keep(v) && seen.add(v.url) && (ignoreShown || v.url !in shownEver)) {
                        shownEver.add(v.url)
                        target.add(v)
                        added++
                    }
                }
            }
        }
        return added
    }

    /** পরে চাপা হতে পারে এমন ভিডিওর তথ্য আগে থেকে আনে, যাতে চাপলে দ্রুত চলে */
    fun prefetch(list: List<VideoItem>) {
        for (v in list) {
            viewModelScope.launch(Dispatchers.IO) {
                runCatching { Repo.streamInfo(v.url) }
            }
        }
    }

    var minimized by mutableStateOf(false)
    var inPip by mutableStateOf(false)

    fun minimizePlayer() {
        minimized = true
    }

    fun videoStarted(v: VideoItem) {
        Keep.videoStart(app, v.title)
    }

    fun closePlayer() {
        current = null
        minimized = false
        Video.stop()
        Keep.videoStop(app)
    }

    fun refreshFeed() {
        feedJob?.cancel()
        feed.clear()
        seen.clear()
        feedQueue.clear()
        feedMessage = null
        feedLoading = false
        loadFeed()
    }

    fun loadFeed(replace: Boolean = false) {
        if (feedLoading) return
        val gen = ++feedGen
        feedJob = viewModelScope.launch {
            feedLoading = true
            try {
                if (replace) {
                    // আগের জমা ভিডিও আগেই দেখানো হয়েছে; নতুনগুলো তৈরি হলে এক ঝটকায় বদলে দেয়
                    val fresh = mutableListOf<VideoItem>()
                    seen.clear()
                    feedPass(false, fresh)
                    if (fresh.isNotEmpty()) {
                        feed.clear()
                        feed.addAll(fresh)
                    }
                } else {
                    val added = feedPass(false)
                    // নতুন কিছু না পেলে আগের দেখানোগুলোও আবার ঘুরিয়ে আনে, যাতে পাতা ফাঁকা না থাকে
                    if (feed.isEmpty() && added == 0) {
                        shownEver.clear()
                        feedPass(true)
                    }
                }
                if (feed.isNotEmpty()) store.saveVideos("feedCache", feed.take(30))
                if (feed.size in 1..40) prefetch(feed.take(4))
                feedMessage = if (feed.isEmpty()) "ভিডিও আনা যায়নি। ইন্টারনেট দেখে ওপর থেকে নিচে টেনে আবার চেষ্টা করুন।" else null
            } finally {
                if (gen == feedGen) {
                    feedLoading = false
                    pulling = false
                }
            }
        }
    }

    // সংরক্ষিত
    val saved = mutableStateListOf<VideoItem>()
    fun isSaved(v: VideoItem): Boolean = saved.any { it.url == v.url }
    fun toggleSave(v: VideoItem) {
        val i = saved.indexOfFirst { it.url == v.url }
        if (i >= 0) saved.removeAt(i) else saved.add(0, v)
        store.saveVideos("saved", saved)
    }

    // পছন্দের (👍) ভিডিও — শুধু এই ফোনে
    val liked = mutableStateListOf<VideoItem>()
    fun isLiked(v: VideoItem): Boolean = liked.any { it.url == v.url }
    fun toggleLike(v: VideoItem) {
        val i = liked.indexOfFirst { it.url == v.url }
        if (i >= 0) liked.removeAt(i) else liked.add(0, v)
        disliked.removeAll { it.url == v.url }
        store.saveVideos("liked", liked)
        store.saveVideos("disliked", disliked)
    }

    // সাবস্ক্রিপশন (শুধু এই ফোনে)
    val subs = mutableStateListOf<ChannelRef>()
    fun isSubscribed(url: String): Boolean = url.isNotEmpty() && subs.any { it.url == url }
    fun toggleSub(c: ChannelRef) {
        val i = subs.indexOfFirst { it.url == c.url }
        if (i >= 0) {
            subs.removeAt(i)
            toast("সাবস্ক্রিপশন বাদ দেওয়া হলো")
        } else {
            subs.add(0, c)
            toast("সাবস্ক্রাইব করা হলো")
        }
        store.saveChannels(subs)
    }

    // 👎 (শুধু এই ফোনে)
    val disliked = mutableStateListOf<VideoItem>()
    fun isDisliked(v: VideoItem): Boolean = disliked.any { it.url == v.url }
    fun toggleDislike(v: VideoItem) {
        val i = disliked.indexOfFirst { it.url == v.url }
        if (i >= 0) disliked.removeAt(i) else {
            disliked.add(0, v)
            if (liked.removeAll { it.url == v.url }) store.saveVideos("liked", liked)
        }
        store.saveVideos("disliked", disliked)
    }

    // ইতিহাস
    val history = mutableStateListOf<VideoItem>()
    fun addHistory(v: VideoItem) {
        history.removeAll { it.url == v.url }
        history.add(0, v)
        while (history.size > 200) history.removeAt(history.size - 1)
        store.saveVideos("history", history)
    }

    fun clearHistory() {
        history.clear()
        store.saveVideos("history", history)
    }

    // ডাউনলোড
    val downloads = mutableStateListOf<DlItem>()
    val dlProgress = mutableStateMapOf<Long, Int>()

    private fun dm(): DownloadManager = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** ফাইলের নাম 'a' দিয়ে শুরু হলে অডিও ডাউনলোড */
    fun isAudioDl(d: DlItem): Boolean = File(d.path).name.startsWith("a")

    fun videoDownload(v: VideoItem): DlItem? = downloads.firstOrNull { it.video.url == v.url && !isAudioDl(it) }

    fun toast(msg: String) {
        Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
    }

    fun startDownload(v: VideoItem, url: String, audio: Boolean = false, ext: String = "mp4"): Boolean {
        if (downloads.any { it.video.url == v.url && isAudioDl(it) == audio }) return false
        val name = (if (audio) "a" else "v") + (v.url.hashCode().toLong() and 0xffffffffL) + "." + ext
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(v.title)
            .setDescription("নিরাপদ টিউব")
            .addRequestHeader("User-Agent", USER_AGENT)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(app, if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES, name)
        val id = dm().enqueue(req)
        val dir = app.getExternalFilesDir(if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES)
        val path = File(dir, name).absolutePath
        downloads.add(0, DlItem(v, id, path))
        store.saveDownloads(downloads)
        dlProgress[id] = 0
        return true
    }

    fun refreshDownloads() {
        for (d in downloads.toList()) {
            var pct = -1
            try {
                val c = dm().query(DownloadManager.Query().setFilterById(d.dlId))
                c?.use {
                    if (it.moveToFirst()) {
                        val st = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val got = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        pct = when (st) {
                            DownloadManager.STATUS_SUCCESSFUL -> 100
                            DownloadManager.STATUS_FAILED -> -1
                            else -> if (total > 0) ((got * 100) / total).toInt().coerceIn(0, 99) else 0
                        }
                    } else if (File(d.path).exists()) {
                        pct = 100
                    }
                }
            } catch (e: Exception) {
                if (File(d.path).exists()) pct = 100
            }
            if (dlProgress[d.dlId] != pct) dlProgress[d.dlId] = pct
        }
    }

    fun deleteDownload(d: DlItem) {
        try { dm().remove(d.dlId) } catch (e: Exception) { }
        try { File(d.path).delete() } catch (e: Exception) { }
        downloads.removeAll { it.dlId == d.dlId }
        dlProgress.remove(d.dlId)
        store.saveDownloads(downloads)
    }

    /** ডাউনলোড সম্পূর্ণ হলে ফাইলের পথ, নইলে null */
    fun localFile(v: VideoItem): String? {
        val d = downloads.firstOrNull { it.video.url == v.url && !isAudioDl(it) } ?: return null
        return if ((dlProgress[d.dlId] ?: 0) == 100 && File(d.path).exists()) d.path else null
    }


    // ---------- শর্টস ----------
    val shorts = mutableStateListOf<VideoItem>()
    var shortsLoading by mutableStateOf(false)
    private val shortQueue = ArrayDeque<String>()
    private val seenShorts = HashSet<String>()

    fun loadShorts() {
        if (shortsLoading) return
        viewModelScope.launch {
            shortsLoading = true
            try {
                var added = 0
                var tries = 0
                while (added < 6 && tries < 4) {
                    if (shortQueue.isEmpty()) feedBase.shuffled().forEach { shortQueue.addLast("$it shorts") }
                    val q = shortQueue.removeFirst()
                    tries++
                    var page = runCatching { withContext(Dispatchers.IO) { Repo.search(q) } }.getOrNull() ?: continue
                    var pages = 0
                    while (true) {
                        for (v in page.items) {
                            if (v.durationSec in 1..65 && keep(v) && seenShorts.add(v.url)) {
                                shorts.add(v)
                                added++
                            }
                        }
                        val nx = page.next
                        if (nx == null || pages >= 2 || added >= 6) break
                        val h = page.handler
                        page = runCatching { withContext(Dispatchers.IO) { Repo.more(h, nx) } }.getOrNull() ?: break
                        pages++
                    }
                }
            } finally {
                shortsLoading = false
            }
        }
    }

    // ---------- মিউজিক (অডিও) ----------
    val music = mutableStateListOf<VideoItem>()
    var musicLoading by mutableStateOf(false)
    var musicMessage by mutableStateOf<String?>(null)
    var musicChip by mutableStateOf(MUSIC_TOPICS[0])
    private var musicHandler: SearchQueryHandler? = null
    private var musicNext: Page? = null
    private var musicJob: Job? = null

    var audioItem by mutableStateOf<VideoItem?>(null)
    var audioPlaying by mutableStateOf(false)
    var audioLoading by mutableStateOf(false)
    private var audioQueue: List<VideoItem> = emptyList()
    private var audioIndex = 0
    private var audioJob: Job? = null
    private var audioGen = 0

    private val audioListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            audioPlaying = isPlaying
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                if (audioIndex + 1 < audioQueue.size) audioNext() else Keep.audioStop(app)
            }
        }
    }

    private suspend fun fillMusic(target: Int) {
        var tries = 0
        while (music.size < target && musicNext != null && tries < 3) {
            val h = musicHandler ?: return
            val p = musicNext ?: return
            val more = withContext(Dispatchers.IO) { Repo.more(h, p) }
            musicNext = more.next
            for (v in more.items) {
                if (keep(v) && music.none { it.url == v.url }) music.add(v)
            }
            tries++
        }
    }

    fun pickMusic(topic: String) {
        musicChip = topic
        musicJob?.cancel()
        music.clear()
        musicHandler = null
        musicNext = null
        musicMessage = null
        musicJob = viewModelScope.launch {
            musicLoading = true
            try {
                val first = withContext(Dispatchers.IO) { Repo.search(topic) }
                musicHandler = first.handler
                musicNext = first.next
                for (v in first.items) if (keep(v) && music.none { it.url == v.url }) music.add(v)
                fillMusic(10)
                if (music.isEmpty()) musicMessage = "কিছু পাওয়া যায়নি।"
            } catch (e: Exception) {
                musicMessage = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                musicLoading = false
            }
        }
    }

    fun loadMoreMusic() {
        if (musicLoading || musicNext == null) return
        musicJob = viewModelScope.launch {
            musicLoading = true
            try {
                fillMusic(music.size + 8)
            } catch (e: Exception) {
                musicNext = null
            } finally {
                musicLoading = false
            }
        }
    }

    fun playAudio(list: List<VideoItem>, index: Int) {
        val v = list.getOrNull(index) ?: return
        audioQueue = list
        audioIndex = index
        audioItem = v
        audioJob?.cancel()
        val gen = ++audioGen
        audioJob = viewModelScope.launch {
            audioLoading = true
            try {
                val info = withContext(Dispatchers.IO) { Repo.streamInfo(v.url) }
                val d = try { info.description?.content ?: "" } catch (e: Exception) { "" }
                val verdict = Screening.check(info, v, d, screenStrict(v))
                if (!verdict.ok) {
                    musicMessage = "🚫 বাদ দেওয়া হলো: " + verdict.reason
                    if (index + 1 < list.size) playAudio(list, index + 1)
                    return@launch
                }
                val src = withContext(Dispatchers.IO) { Repo.buildAudioSource(info) }
                if (src == null) {
                    musicMessage = "এই অডিওর লিংক পাওয়া যায়নি"
                    if (index + 1 < list.size) playAudio(list, index + 1)
                    return@launch
                }
                Audio.player.setMediaSource(src)
                Audio.player.prepare()
                Audio.player.playWhenReady = true
                Keep.audioStart(app, v.title)
            } catch (e: Exception) {
                musicMessage = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                if (gen == audioGen) audioLoading = false
            }
        }
    }

    fun audioNext() {
        if (audioIndex + 1 < audioQueue.size) playAudio(audioQueue, audioIndex + 1)
    }

    fun audioPrev() {
        if (audioIndex > 0) playAudio(audioQueue, audioIndex - 1)
    }

    fun toggleAudio() {
        val p = Audio.player
        if (p.isPlaying) p.pause() else p.play()
    }

    fun stopAudio() {
        audioJob?.cancel()
        audioGen++
        audioLoading = false
        Audio.player.stop()
        audioItem = null
        Keep.audioStop(app)
    }


    // ---------- মিউজিক লাইব্রেরি, অডিও ডাউনলোড ----------
    val musicLib = mutableStateListOf<VideoItem>()

    fun inMusicLib(v: VideoItem): Boolean = musicLib.any { it.url == v.url }

    fun toggleMusicLib(v: VideoItem) {
        val i = musicLib.indexOfFirst { it.url == v.url }
        if (i >= 0) {
            musicLib.removeAt(i)
            toast("লাইব্রেরি থেকে সরানো হলো")
        } else {
            musicLib.add(0, v)
            toast("মিউজিক লাইব্রেরিতে রাখা হলো")
        }
        store.saveVideos("musicLib", musicLib)
    }

    fun downloadAudio(v: VideoItem) {
        if (downloads.any { it.video.url == v.url && isAudioDl(it) }) {
            toast("এই অডিও আগেই ডাউনলোডে আছে")
            return
        }
        toast("অডিও ডাউনলোডের জন্য প্রস্তুত হচ্ছে…")
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Repo.streamInfo(v.url) }
                val d = try { info.description?.content ?: "" } catch (e: Exception) { "" }
                val verdict = Screening.check(info, v, d, screenStrict(v))
                if (!verdict.ok) {
                    toast("🚫 ডাউনলোড করা যাবে না: " + verdict.reason)
                    return@launch
                }
                val a = Repo.bestAudio(info)
                if (a == null) {
                    toast("অডিওর লিংক পাওয়া যায়নি")
                    return@launch
                }
                startDownload(v, a.first, audio = true, ext = a.second)
                toast("ডাউনলোড শুরু হয়েছে (লাইব্রেরি → ডাউনলোড)")
            } catch (e: Exception) {
                toast("সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    /** ডাউনলোড করা অডিও মিউজিক প্লেয়ারে চালায় */
    fun playLocalAudio(d: DlItem) {
        val v = d.video
        audioQueue = listOf(v)
        audioIndex = 0
        audioItem = v
        audioJob?.cancel()
        audioGen++
        audioLoading = false
        Audio.player.setMediaItem(MediaItem.fromUri(Uri.fromFile(File(d.path))))
        Audio.player.prepare()
        Audio.player.playWhenReady = true
        Keep.audioStart(app, v.title)
    }

    // ---------- চ্যানেল পাতা ----------
    var channelOpen by mutableStateOf(false)
    var channelName by mutableStateOf("")
    var channelIcon by mutableStateOf<String?>(null)
    var channelSubs by mutableStateOf(-1L)
    var channelLoading by mutableStateOf(false)
    var channelMessage by mutableStateOf<String?>(null)
    val channelVideos = mutableStateListOf<VideoItem>()
    private var channelUrlCur = ""
    private var channelTab: ListLinkHandler? = null
    private var channelNext: Page? = null
    private var channelJob: Job? = null

    // চ্যানেল পাতায় সব ভিডিও আসে; শুধু খারাপ শব্দওয়ালাগুলো বাদ যায়
    private fun keepChannel(v: VideoItem): Boolean {
        val ok = ContentFilter.textScore(v.title + " " + v.channel) >= 0
        if (ok) travelOk.add(v.url)
        return ok
    }

    fun openChannel(url: String, name: String, icon: String?) {
        channelOpen = true
        channelName = name
        channelIcon = icon
        channelSubs = -1L
        channelVideos.clear()
        channelMessage = null
        channelTab = null
        channelNext = null
        channelUrlCur = url
        channelJob?.cancel()
        if (url.isBlank()) {
            channelMessage = "এই ভিডিওর চ্যানেলের তথ্য পাওয়া যায়নি।"
            return
        }
        channelJob = viewModelScope.launch {
            channelLoading = true
            try {
                val data = withContext(Dispatchers.IO) { Repo.channel(url) }
                if (data.name.isNotEmpty()) channelName = data.name
                if (data.icon != null) channelIcon = data.icon
                channelSubs = data.subs
                channelTab = data.tab
                channelNext = data.next
                for (v in data.items) if (keepChannel(v)) channelVideos.add(v)
                if (channelVideos.isEmpty()) channelMessage = "এই চ্যানেলের কোনো ভিডিও পাওয়া যায়নি।"
            } catch (e: Exception) {
                channelMessage = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                channelLoading = false
            }
        }
    }

    fun loadMoreChannel() {
        val tab = channelTab ?: return
        val pg = channelNext ?: return
        if (channelLoading) return
        channelJob = viewModelScope.launch {
            channelLoading = true
            try {
                val (items, nx) = withContext(Dispatchers.IO) { Repo.channelMore(tab, pg, channelName, channelUrlCur, channelIcon) }
                channelNext = nx
                for (v in items) if (keepChannel(v) && channelVideos.none { it.url == v.url }) channelVideos.add(v)
            } catch (e: Exception) {
                channelNext = null
            } finally {
                channelLoading = false
            }
        }
    }

    fun closeChannel() {
        channelOpen = false
    }

    override fun onCleared() {
        Audio.player.removeListener(audioListener)
        super.onCleared()
    }

    init {
        Audio.player.addListener(audioListener)
    }

    init {
        saved.addAll(store.loadVideos("saved"))
        liked.addAll(store.loadVideos("liked"))
        musicLib.addAll(store.loadVideos("musicLib"))
        history.addAll(store.loadVideos("history"))
        downloads.addAll(store.loadDownloads())
        refreshDownloads()
        subs.addAll(store.loadChannels())
        disliked.addAll(store.loadVideos("disliked"))
        val cached = store.loadVideos("feedCache")
        if (cached.isNotEmpty()) {
            feed.addAll(cached)
            seen.addAll(cached.map { it.url })
            loadFeed(replace = true)
        } else {
            loadFeed()
        }
    }
}
