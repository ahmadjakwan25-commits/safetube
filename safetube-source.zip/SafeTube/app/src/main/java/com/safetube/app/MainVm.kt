package com.safetube.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler

class MainVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("safetube", Context.MODE_PRIVATE)

    var query by mutableStateOf("")
    var items by mutableStateOf<List<VideoItem>>(emptyList())
    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var current by mutableStateOf<VideoItem?>(null)
    var showSettings by mutableStateOf(false)
    var islamicOnly by mutableStateOf(prefs.getBoolean("islamicOnly", false))
        private set

    var canLoadMore by mutableStateOf(false)
        private set

    private var handler: SearchQueryHandler? = null
    private var nextPage: Page? = null
    private var job: Job? = null

    fun setIslamicOnly(v: Boolean) {
        islamicOnly = v
        prefs.edit().putBoolean("islamicOnly", v).apply()
    }

    private fun keep(v: VideoItem): Boolean {
        val text = v.title + " " + v.channel
        if (ContentFilter.isBad(text)) return false
        if (islamicOnly && !ContentFilter.isIslamic(text)) return false
        return true
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return
        query = text
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            message = null
            items = emptyList()
            canLoadMore = false
            handler = null
            nextPage = null
            try {
                if (ContentFilter.isBad(text)) {
                    message = "এই বিষয়টি এখানে খোঁজা যায় না।"
                    return@launch
                }
                val first = withContext(Dispatchers.IO) { Repo.search(text) }
                handler = first.handler
                nextPage = first.next
                val found = first.items.filter { keep(it) }.toMutableList()
                var tries = 0
                while (found.size < 10 && nextPage != null && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(handler!!, nextPage!!) }
                    nextPage = more.next
                    found += more.items.filter { keep(it) }
                    tries++
                }
                items = found
                canLoadMore = nextPage != null
                if (found.isEmpty()) message = "কিছু পাওয়া যায়নি।"
            } catch (e: Exception) {
                message = "সমস্যা হয়েছে: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
            }
        }
    }

    fun loadMore() {
        val h = handler ?: return
        val p = nextPage ?: return
        if (loading) return
        job = viewModelScope.launch {
            loading = true
            try {
                val found = mutableListOf<VideoItem>()
                var page: Page? = p
                var tries = 0
                while (page != null && found.size < 10 && tries < 3) {
                    val more = withContext(Dispatchers.IO) { Repo.more(h, page!!) }
                    page = more.next
                    found += more.items.filter { keep(it) }
                    tries++
                }
                nextPage = page
                items = items + found
                canLoadMore = page != null
            } catch (e: Exception) {
                message = "আরও আনা যায়নি: " + (e.message ?: e.javaClass.simpleName)
            } finally {
                loading = false
            }
        }
    }
}
