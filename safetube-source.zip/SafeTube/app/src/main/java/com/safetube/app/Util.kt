package com.safetube.app

import android.content.Context
import android.content.Intent

/** ভিডিও বা গানের লিংক অন্য অ্যাপে শেয়ার করে */
fun shareLink(ctx: Context, title: String, url: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, title)
        putExtra(Intent.EXTRA_TEXT, title + "\n" + url)
    }
    try {
        ctx.startActivity(Intent.createChooser(send, "শেয়ার করুন"))
    } catch (e: Exception) { }
}
