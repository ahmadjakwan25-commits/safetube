package com.safetube.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val t = vm.theme
            // স্ট্যাটাস বার ও নিচের বারের আইকন থিমের সাথে মিলিয়ে সাদা/কালো
            val lightTop = t.headerStyle == HeaderStyle.YOUTUBE && !t.dark
            SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = if (lightTop) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    else SystemBarStyle.dark(Color.TRANSPARENT),
                    navigationBarStyle = if (t.dark) SystemBarStyle.dark(Color.TRANSPARENT)
                    else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                )
            }
            SafeTubeTheme(t) {
                Root(vm)
            }
        }
    }
}

@Composable
fun Root(vm: MainVm) {
    val playing = vm.current
    BackHandler(enabled = playing != null) { vm.current = null }
    BackHandler(enabled = playing == null && vm.tab != Tab.HOME) { vm.tab = Tab.HOME }
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        if (playing == null) {
            MainScreen(vm)
        } else {
            key(playing.url) {
                PlayerScreen(playing, vm) { vm.current = null }
            }
        }
    }
}
