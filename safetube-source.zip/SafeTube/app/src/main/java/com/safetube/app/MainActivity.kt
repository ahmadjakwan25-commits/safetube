package com.safetube.app

import android.Manifest
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.util.Rational
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // হোম বা অ্যাপ বদলালে ভিডিও চলতে থাকলে ছোট ভাসমান জানালায় (PiP) চলতে থাকে
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vm.current != null && Video.currentUrl != null && Video.player.isPlaying) {
            try {
                val sz = Video.player.videoSize
                val r = if (sz.width > 0 && sz.height > 0) sz.width.toDouble() / sz.height else 16.0 / 9.0
                val ratio = Rational((r.coerceIn(0.45, 2.3) * 1000).toInt(), 1000)
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
            } catch (e: Exception) { }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        vm.inPip = isInPictureInPictureMode
    }

    override fun onStop() {
        super.onStop()
        // ছোট জানালা ✕ দিয়ে বন্ধ করলে ভিডিও থেমে যায়
        if (isInPictureInPictureMode && vm.current != null) vm.closePlayer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val t = vm.theme
            // স্ট্যাটাস বার ও নিচের বারের আইকন থিমের সাথে মিলিয়ে সাদা/কালো
            val lightTop = t.headerStyle == HeaderStyle.YOUTUBE && !t.dark
            SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = if (lightTop) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    else SystemBarStyle.dark(Color.TRANSPARENT),
                    navigationBarStyle = if (t.dark) SystemBarStyle.dark(Color.TRANSPARENT)
                    else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                )
            }
            SafeTubeTheme(t) {
                Root(vm)
            }
        }
    }
}

@Composable
fun Root(vm: MainVm) {
    val playing = vm.current
    // ব্যাক চাপলে ভিডিও বন্ধ না হয়ে ছোট হয়ে যায়
    BackHandler(enabled = playing != null && !vm.minimized && !vm.inPip) { vm.minimizePlayer() }
    BackHandler(enabled = (playing == null || vm.minimized) && vm.tab != Tab.HOME) { vm.tab = Tab.HOME }
    // নতুন ভিডিও চাপলে সেটা সরাসরি বড় হয়ে খোলে
    LaunchedEffect(playing?.url) { vm.minimized = false }
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        if (playing != null && vm.inPip) {
            PipVideo()
        } else if (playing == null || vm.minimized) {
            MainScreen(vm)
        } else {
            key(playing.url) {
                PlayerScreen(playing, vm) { vm.minimizePlayer() }
            }
        }
    }
}
