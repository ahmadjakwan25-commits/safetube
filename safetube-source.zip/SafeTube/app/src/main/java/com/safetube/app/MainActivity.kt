package com.safetube.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SafeTubeTheme {
                Root(vm)
            }
        }
    }
}

@Composable
fun Root(vm: MainVm) {
    val playing = vm.current
    BackHandler(enabled = playing != null) { vm.current = null }
    if (playing == null) {
        HomeScreen(vm)
    } else {
        PlayerScreen(playing) { vm.current = null }
    }
}
