package com.safetube.app

import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

data class VideoItem(
    val url: String,
    val title: String,
    val channel: String,
    val thumb: String?,
    val durationSec: Long,
    val views: Long
)

data class CommentItem(val author: String, val text: String, val likes: Int, val date: String)

class CommentPage(val items: List<CommentItem>, val next: Page?, val info: CommentsInfo)

fun fmtCount(n: Long): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
    n >= 1_000 -> "%.1fK".format(n / 1_000.0)
    else -> n.toString()
}

class SearchPage(val handler: SearchQueryHandler, val items: List<VideoItem>, val next: Page?)

object Repo {
    private val yt get() = ServiceList.YouTube

    fun search(q: String): SearchPage {
        val h = yt.searchQHFactory.fromQuery(q, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val info = SearchInfo.getInfo(yt, h)
        return SearchPage(h, map(info.relatedItems), info.nextPage)
    }

    fun more(h: SearchQueryHandler, page: Page): SearchPage {
        val p = SearchInfo.getMoreItems(yt, h, page)
        return SearchPage(h, map(p.items), p.nextPage)
    }

    private fun map(list: List<InfoItem>): List<VideoItem> =
        list.filterIsInstance<StreamInfoItem>().map {
            VideoItem(
                url = it.url,
                title = it.name ?: "",
                channel = it.uploaderName ?: "",
                thumb = it.thumbnails.firstOrNull()?.url,
                durationSec = it.duration,
                views = it.viewCount
            )
        }

    private fun mapComments(list: List<CommentsInfoItem>): List<CommentItem> = list.map {
        val raw: Any? = it.commentText
        val text = (raw as? org.schabi.newpipe.extractor.stream.Description)?.content ?: (raw?.toString() ?: "")
        CommentItem(it.uploaderName ?: "", text, it.likeCount, it.textualUploadDate ?: "")
    }

    fun comments(info: StreamInfo): CommentPage {
        val ci = CommentsInfo.getInfo(info.url)
        return CommentPage(mapComments(ci.relatedItems), ci.nextPage, ci)
    }

    fun moreComments(ci: CommentsInfo, page: Page): CommentPage {
        val p = CommentsInfo.getMoreItems(yt, ci, page)
        return CommentPage(mapComments(p.items), p.nextPage, ci)
    }

    // একই ভিডিওর তথ্য ২০ মিনিট মনে রাখে, তাই দ্বিতীয়বার বা আগে থেকে আনা ভিডিও সাথে সাথে চলে
    private val infoCache = LinkedHashMap<String, Pair<Long, StreamInfo>>()

    fun streamInfo(url: String): StreamInfo {
        synchronized(infoCache) {
            val e = infoCache[url]
            if (e != null && System.currentTimeMillis() - e.first < 20 * 60 * 1000) return e.second
        }
        val info = StreamInfo.getInfo(yt, url)
        synchronized(infoCache) {
            infoCache[url] = System.currentTimeMillis() to info
            while (infoCache.size > 16) infoCache.remove(infoCache.keys.first())
        }
        return info
    }

    fun invalidate(url: String) {
        synchronized(infoCache) { infoCache.remove(url) }
    }

    class Candidate(val label: String, val make: () -> MediaSource)

    private fun fmtLabel(st: VideoStream): String {
        val suffix = try { st.format?.suffix?.uppercase() ?: "" } catch (e: Exception) { "" }
        val hd = if (st.height >= 720) " HD" else ""
        return (st.height.toString() + "p " + suffix + hd).trim()
    }

    /** চালানোর উপায়গুলো সেরা থেকে কম ভালো ক্রমে; একটা ব্যর্থ হলে পরেরটা চেষ্টা হয় */
    fun candidates(info: StreamInfo): List<Candidate> {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setAllowCrossProtocolRedirects(true)
        val pf = ProgressiveMediaSource.Factory(http)
        val list = mutableListOf<Candidate>()

        val muxed = info.videoStreams.filter { !it.isVideoOnly && !it.content.isNullOrEmpty() }
        val ordered = muxed.filter { it.height <= 720 }.sortedByDescending { it.height } +
            muxed.filter { it.height > 720 }.sortedBy { it.height }
        for (st in ordered) {
            val u = st.content
            list.add(Candidate(fmtLabel(st)) { pf.createMediaSource(MediaItem.fromUri(u)) })
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrEmpty()) {
            list.add(Candidate("অটো (HLS)") { HlsMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(hls)) })
        }
        // উচ্চ মান: ভিডিও আর অডিও আলাদা ফাইল জোড়া লাগিয়ে (সব সময় না-ও চলতে পারে)
        val vOnly = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }
        val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }
        if (a != null) {
            val au = a.content
            for (h in listOf(1080, 720, 480)) {
                val same = vOnly.filter { it.height == h }
                val v = same.firstOrNull { (try { it.format?.suffix } catch (e: Exception) { null }) == "mp4" } ?: same.firstOrNull() ?: continue
                val vu = v.content
                list.add(Candidate(fmtLabel(v) + " (জোড়া)") {
                    MergingMediaSource(
                        pf.createMediaSource(MediaItem.fromUri(vu)),
                        pf.createMediaSource(MediaItem.fromUri(au))
                    )
                })
            }
        }
        return list
    }

    /** শুধু অডিও স্ট্রিম (মিউজিক ট্যাবের জন্য), না পেলে সাধারণ ভিডিও স্ট্রিম */
    fun buildAudioSource(info: StreamInfo): MediaSource? {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }
        if (a != null) {
            return ProgressiveMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(a.content))
        }
        return buildSource(info)
    }

    /** ভিডিও + অডিও একসাথে থাকা সোজা স্ট্রিম আগে, না থাকলে HLS */
    fun buildSource(info: StreamInfo): MediaSource? {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)

        val best = bestMuxed(info)
        if (best != null) {
            return ProgressiveMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(best.content))
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrEmpty()) {
            return HlsMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(hls))
        }
        return null
    }
}

/** একটা উপায়ে না চললে (ত্রুটি হলে) নিজে থেকে পরের উপায় চেষ্টা করে; মান বদলালে আগের জায়গা থেকেই চলে */
class SourceRunner(
    private val player: ExoPlayer,
    private val cands: List<Repo.Candidate>,
    var onFail: (String) -> Unit,
    var onIndex: (Int) -> Unit = {}
) : Player.Listener {
    var index = 0
        private set

    fun start() {
        player.addListener(this)
        tryIdx(0, 0L)
    }

    fun switchTo(i: Int) {
        tryIdx(i, player.currentPosition)
    }

    private fun tryIdx(i: Int, pos: Long) {
        index = i
        onIndex(i)
        val c = cands.getOrNull(i)
        if (c == null) {
            onFail("চালানোর মতো কোনো লিংক পাওয়া যায়নি")
            return
        }
        try {
            player.setMediaSource(c.make(), pos)
            player.prepare()
            player.playWhenReady = true
        } catch (e: Exception) {
            tryIdx(i + 1, pos)
        }
    }

    override fun onPlayerError(error: PlaybackException) {
        if (index + 1 < cands.size) tryIdx(index + 1, player.currentPosition) else onFail(error.errorCodeName)
    }

    fun stop() {
        player.removeListener(this)
    }
}
