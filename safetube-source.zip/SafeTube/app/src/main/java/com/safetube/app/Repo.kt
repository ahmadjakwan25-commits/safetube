package com.safetube.app

import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

data class VideoItem(
    val url: String,
    val title: String,
    val channel: String,
    val thumb: String?,
    val durationSec: Long,
    val views: Long
)

data class CommentItem(val author: String, val text: String, val likes: Int, val date: String)

class CommentPage(val items: List<CommentItem>, val next: Page?, val info: CommentsInfo)

fun fmtCount(n: Long): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
    n >= 1_000 -> "%.1fK".format(n / 1_000.0)
    else -> n.toString()
}

class SearchPage(val handler: SearchQueryHandler, val items: List<VideoItem>, val next: Page?)

object Repo {
    private val yt get() = ServiceList.YouTube

    fun search(q: String): SearchPage {
        val h = yt.searchQHFactory.fromQuery(q, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val info = SearchInfo.getInfo(yt, h)
        return SearchPage(h, map(info.relatedItems), info.nextPage)
    }

    fun more(h: SearchQueryHandler, page: Page): SearchPage {
        val p = SearchInfo.getMoreItems(yt, h, page)
        return SearchPage(h, map(p.items), p.nextPage)
    }

    private fun map(list: List<InfoItem>): List<VideoItem> =
        list.filterIsInstance<StreamInfoItem>().map {
            VideoItem(
                url = it.url,
                title = it.name ?: "",
                channel = it.uploaderName ?: "",
                thumb = it.thumbnails.firstOrNull()?.url,
                durationSec = it.duration,
                views = it.viewCount
            )
        }

    private fun mapComments(list: List<CommentsInfoItem>): List<CommentItem> = list.map {
        val raw: Any? = it.commentText
        val text = (raw as? org.schabi.newpipe.extractor.stream.Description)?.content ?: (raw?.toString() ?: "")
        CommentItem(it.uploaderName ?: "", text, it.likeCount, it.textualUploadDate ?: "")
    }

    fun comments(info: StreamInfo): CommentPage {
        val ci = CommentsInfo.getInfo(info)
        return CommentPage(mapComments(ci.relatedItems), ci.nextPage, ci)
    }

    fun moreComments(ci: CommentsInfo, page: Page): CommentPage {
        val p = CommentsInfo.getMoreItems(yt, ci, page)
        return CommentPage(mapComments(p.items), p.nextPage, ci)
    }

    fun streamInfo(url: String): StreamInfo = StreamInfo.getInfo(yt, url)

    /** অডিওসহ সোজা ভিডিও স্ট্রিম, ৭২০p বা তার নিচের সেরাটা */
    fun bestMuxed(info: StreamInfo): VideoStream? {
        val muxed = info.videoStreams.filter { !it.isVideoOnly && !it.content.isNullOrEmpty() }
        return muxed.filter { it.height <= 720 }.maxByOrNull { it.height } ?: muxed.firstOrNull()
    }

    fun muxedUrl(info: StreamInfo): String? = bestMuxed(info)?.content

    /** এই ভিডিওর সাথে মিলিয়ে আসা অন্য ভিডিও */
    fun related(info: StreamInfo): List<VideoItem> = try {
        map(info.relatedItems)
    } catch (e: Exception) {
        emptyList()
    }

    /** ভিডিও + অডিও একসাথে থাকা সোজা স্ট্রিম আগে, না থাকলে HLS */
    fun buildSource(info: StreamInfo): MediaSource? {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)

        val best = bestMuxed(info)
        if (best != null) {
            return ProgressiveMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(best.content))
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrEmpty()) {
            return HlsMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(hls))
        }
        return null
    }
}
