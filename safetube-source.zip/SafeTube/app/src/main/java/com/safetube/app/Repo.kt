package com.safetube.app

import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class VideoItem(
    val url: String,
    val title: String,
    val channel: String,
    val thumb: String?,
    val durationSec: Long,
    val views: Long
)

class SearchPage(val handler: SearchQueryHandler, val items: List<VideoItem>, val next: Page?)

object Repo {
    private val yt get() = ServiceList.YouTube

    fun search(q: String): SearchPage {
        val h = yt.searchQHFactory.fromQuery(q, listOf(YoutubeSearchQueryHandlerFactory.VIDEOS), "")
        val info = SearchInfo.getInfo(yt, h)
        return SearchPage(h, map(info.relatedItems), info.nextPage)
    }

    fun more(h: SearchQueryHandler, page: Page): SearchPage {
        val p = SearchInfo.getMoreItems(yt, h, page)
        return SearchPage(h, map(p.items), p.nextPage)
    }

    private fun map(list: List<InfoItem>): List<VideoItem> =
        list.filterIsInstance<StreamInfoItem>().map {
            VideoItem(
                url = it.url,
                title = it.name ?: "",
                channel = it.uploaderName ?: "",
                thumb = it.thumbnails.firstOrNull()?.url,
                durationSec = it.duration,
                views = it.viewCount
            )
        }

    fun streamInfo(url: String): StreamInfo = StreamInfo.getInfo(yt, url)

    /** ভিডিও + অডিও একসাথে থাকা সোজা স্ট্রিম আগে, না থাকলে HLS */
    fun buildSource(info: StreamInfo): MediaSource? {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)

        val muxed = info.videoStreams.filter { !it.isVideoOnly && !it.content.isNullOrEmpty() }
        val best = muxed.filter { it.height <= 720 }.maxByOrNull { it.height } ?: muxed.firstOrNull()
        if (best != null) {
            return ProgressiveMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(best.content))
        }
        val hls = info.hlsUrl
        if (!hls.isNullOrEmpty()) {
            return HlsMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(hls))
        }
        return null
    }
}
