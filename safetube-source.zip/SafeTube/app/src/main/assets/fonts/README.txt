Tiro Bangla (TiroBangla-Regular.ttf) এখানে বসে। GitHub Actions বিল্ডের সময় নিজে থেকে নামিয়ে বসায়।
